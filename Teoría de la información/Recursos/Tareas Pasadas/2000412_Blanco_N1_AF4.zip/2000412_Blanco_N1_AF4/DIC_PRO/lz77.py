import sys # <-- Importar sys para leer la entrada estándar

def lz77_compress(text, history_size=20, lookahead_size=8):
    """
    Comprime un texto usando el algoritmo LZ77 con la lógica de salida de 
    pares (offset, length) o caracteres literales.
    
    Args:
        text (str): El texto de entrada a comprimir.
        history_size (int): El tamaño de la ventana de histórico (diccionario).
        lookahead_size (int): El tamaño de la ventana de búsqueda (lookahead).
        
    Returns:
        list: Una lista de tuplas (offset, length) y caracteres (literales).
    """
    
    output_list = []
    cursor = 0
    
    print(f"Texto original: '{text}'")
    print(f"Tamaño de histórico: {history_size}, Tamaño de lookahead: {lookahead_size}\n")
    print("-" * 50)

    # --- INICIO DE LA MODIFICACIÓN ---
    # "Pre-carga" silenciosa de los primeros 'history_size' caracteres.
    # Estos siempre se emiten como literales (0, 0, C).
    # Hacemos esto ANTES del bucle 'while' principal para que 
    # el "paso a paso" impreso comience con el historial lleno.
    
    preload_count = min(len(text), history_size)
    
    for i in range(preload_count):
        # Añade los literales iniciales a la lista de salida
        output_list.append((0, 0, text[i]))
    
    # El cursor principal AHORA comienza en la posición 'history_size'
    cursor = preload_count
    
    # Imprimir un mensaje de que la pre-carga se hizo
    if cursor > 0 and cursor < len(text):
        print(f"NOTA: Pre-cargados {cursor} caracteres iniciales como literales.")
        print(f"      (Estos {cursor} pasos no se mostrarán en el log detallado).")
        print("Iniciando compresión principal con historial lleno...")
        print("-" * 50)
    elif cursor == len(text):
        print("NOTA: El texto es más corto o igual que el historial.")
        print("Todos los caracteres se han procesado como literales.")
    # --- FIN DE LA MODIFICACIÓN ---


    while cursor < len(text):
        # 1. Definir las ventanas de histórico y búsqueda
        
        # El histórico son los N caracteres *antes* del cursor
        history_start = max(0, cursor - history_size)
        history = text[history_start:cursor]
        
        # El lookahead son los M caracteres *desde* el cursor hacia adelante
        lookahead_end = min(len(text), cursor + lookahead_size)
        lookahead = text[cursor:lookahead_end]

        # Si el lookahead está vacío, terminamos
        if not lookahead:
            break
            
        # Imprimir el estado actual
        # Usamos rjust y ljust para alinear las ventanas como en el ejemplo
        print(f"Histórico: [{history.rjust(history_size)}]")
        print(f"Lookahead: [{lookahead.ljust(lookahead_size)}]")

        # 2. Encontrar la coincidencia más larga
        best_offset = 0
        best_length = 0

        # Iteramos desde la longitud más larga posible hacia abajo
        for length in range(len(lookahead), 0, -1):
            phrase = lookahead[:length]
            
            # Buscamos la *última* aparición (más cercana) de la frase en el histórico
            # rfind() nos da el índice de la última ocurrencia, o -1 si no se encuentra
            found_index = history.rfind(phrase)
            
            if found_index != -1:
                # Coincidencia encontrada
                # El offset se cuenta desde el final del histórico (inicio del lookahead)
                best_offset = len(history) - found_index
                best_length = length
                
                # Encontramos la más larga, salimos del bucle
                break

        # 3. Generar la salida y mover el cursor (NUEVA LÓGICA DE TRIPLA)
        
        # --- INICIO DE LA MODIFICACIÓN ---
        
        # Determinar el caracter 'siguiente'
        # La posición del 'siguiente caracter' es después de la coincidencia
        next_char_index = cursor + best_length
        
        if next_char_index < len(text):
            # Caso normal: tomamos el siguiente caracter
            next_char = text[next_char_index]
            # Avanzamos la longitud de la coincidencia + 1 (por el 'next_char')
            cursor_move = best_length + 1
        else:
            # Caso especial: Estamos al final del texto.
            # La "coincidencia" (incluso si es de longitud 0) llega hasta el final.
            # No hay 'siguiente caracter'. Usamos un marcador (ej. string vacío).
            next_char = '' 
            # Avanzamos para terminar el bucle
            cursor_move = best_length + 1 
        
        # Generar la tripla.
        # Si no hubo coincidencia (best_length=0, best_offset=0):
        # next_char = text[cursor+0] = text[cursor]
        # cursor_move = 0 + 1 = 1
        # La salida es (0, 0, 'C') -> Esto es un literal.
        output_tuple = (best_offset, best_length, next_char)
        print(f"Salida:    {output_tuple}\n")
        output_list.append(output_tuple)
        
        # Mover el cursor
        cursor += cursor_move
        
        # (Se elimina el bloque 'if/else' anterior)
        # --- FIN DE LA MODIFICACIÓN ---
            
        print("-" * 50)

    print("Compresión finalizada.")
    print(f"Salida final: {output_list}")
    return output_list

# --- INICIO DE LA NUEVA MODIFICACIÓN ---
# Esta clase nos permite "duplicar" la salida de print()
# para que vaya tanto a la terminal (stdout) como a un archivo.
class TeeLogger:
    def __init__(self, filename, mode='w', encoding='utf-8'):
        self.terminal = sys.stdout
        self.file = open(filename, mode, encoding=encoding)

    def write(self, message):
        self.terminal.write(message)
        self.file.write(message)

    def flush(self):
        # Esta función es necesaria para la compatibilidad con stdout
        self.terminal.flush()
        self.file.flush()

    def close(self):
        self.file.close()

# --- FIN DE LA NUEVA MODIFICACIÓN ---

# --- Ejecución del script ---
if __name__ == "__main__":
    
    # Parámetros definidos en la solicitud
    HISTORY_WINDOW = 20
    LOOKAHEAD_WINDOW = 8
    
    # --- MODIFICACIÓN ---
    print("--- Compresor LZ77 Interactivo ---")
    print("Pega el texto que deseas comprimir (puede ser multi-línea).")
    print("Cuando termines, presiona Ctrl+D (Linux/macOS) o Ctrl+Z + Enter (Windows).")
    print("-" * 38)
    
    # --- INICIO DE LA NUEVA MODIFICACIÓN ---
    output_filename = "resultado-lz77.txt"
    original_stdout = sys.stdout  # Guardamos la salida original
    logger = None
    # --- FIN DE LA NUEVA MODIFICACIÓN ---

    try:
        # Leer todo el texto pegado de la entrada estándar y limpiar espacios
        INPUT_TEXT = sys.stdin.read().strip() 
        
        if not INPUT_TEXT:
            print("\nNo se ingresó texto. Saliendo.")
        else:
            # --- INICIO DE LA NUEVA MODIFICACIÓN ---
            # Redirigir stdout a nuestro TeeLogger
            # A partir de este punto, CUALQUIER print() irá
            # tanto a la consola como al archivo.
            logger = TeeLogger(output_filename, 'w', encoding='utf-8')
            sys.stdout = logger
            
            print("--- Compresor LZ77 Interactivo ---")
            print(f"Salida de este proceso guardada en: {output_filename}\n")
            # --- FIN DE LA NUEVA MODIFICACIÓN ---
            
            print("\nTexto recibido. Iniciando compresión...")
            print("-" * 38 + "\n")
            # Ejecutar la compresión
            # Todas las sentencias 'print' dentro de esta función
            # ahora serán capturadas por el TeeLogger.
            compressed_data = lz77_compress(INPUT_TEXT, HISTORY_WINDOW, LOOKAHEAD_WINDOW)
            
            # --- INICIO DE LA NUEVA MODIFICACIÓN ---
            # Restauramos la salida estándar original
            sys.stdout = original_stdout
            if logger:
                logger.close()
                logger = None
            
            print("\n" + "=" * 50)
            print(f"Proceso completado. El paso a paso ha sido guardado en: {output_filename}")
            print("=" * 50)
            
            # Eliminamos la escritura de archivo anterior, ya no es necesaria.
            # --- FIN DE LA NUEVA MODIFICACIÓN ---
    
    except KeyboardInterrupt:
        print("\n\nCompresión cancelada por el usuario.")
    
    finally:
        # Nos aseguramos de restaurar stdout y cerrar el archivo
        # incluso si ocurre un error durante la compresión.
        if logger:
            logger.close()
        sys.stdout = original_stdout

"""
Mostrar el radio de comprehension
"""