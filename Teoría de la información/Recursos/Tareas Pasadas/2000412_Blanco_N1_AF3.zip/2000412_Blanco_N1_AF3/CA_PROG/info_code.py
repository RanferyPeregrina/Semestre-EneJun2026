import sys
import string

# Configuración de precisión para flotantes (opcional, para visualización)
PRECISION = 10

def limpiar_texto(texto):
    """
    Limpia el texto: elimina espacios, signos de puntuación y números.
    Convierte todo a minúsculas.
    Retorna solo letras de la a-z.
    """
    texto_limpio = []
    for char in texto.lower():
        if char.isalpha():
            texto_limpio.append(char)
    return "".join(texto_limpio)

def obtener_entrada(mensaje):
    """
    Solicita entrada al usuario, soporta multilínea hasta EOF.
    """
    print(f"\n--- {mensaje} ---")
    print("Introduce el texto. Al finalizar, presiona Ctrl+D (Mac/Linux) o Ctrl+Z (Windows).")
    lineas = []
    try:
        while True:
            try:
                linea = input()
                lineas.append(linea)
            except EOFError:
                break
        return "\n".join(lineas).strip()
    except KeyboardInterrupt:
        sys.exit(0)

def calcular_probabilidades(texto_referencia):
    """
    Calcula la probabilidad de cada carácter en el texto de referencia.
    Retorna un diccionario {caracter: probabilidad} y la lista de caracteres únicos ordenados.
    """
    total = len(texto_referencia)
    conteo = {}
    for char in texto_referencia:
        conteo[char] = conteo.get(char, 0) + 1
    
    probabilidades = {char: count / total for char, count in conteo.items()}
    # Ordenar caracteres de la A a la Z
    caracteres_ordenados = sorted(probabilidades.keys())
    
    return probabilidades, caracteres_ordenados

def main():
    print("=== CODIFICACIÓN ARITMÉTICA ===")

    # 1. Obtener texto de referencia para el modelo
    texto_ref_raw = obtener_entrada("Paso 1: Texto de Referencia (para probabilidades)")
    texto_ref = limpiar_texto(texto_ref_raw)
    
    if not texto_ref:
        print("Error: El texto de referencia no contiene letras válidas.")
        return

    # 2. Calcular probabilidades iniciales
    probs, chars_ordenados = calcular_probabilidades(texto_ref)

    # Mostrar probabilidades base
    print("\n--- Probabilidades Base (Orden A-Z) ---")
    for c in chars_ordenados:
        print(f"'{c}': {probs[c]:.6f}")

    # 3. Obtener palabra a codificar
    palabra_raw = input("\nIntroduce la palabra a codificar (una sola línea): ").strip()
    palabra = limpiar_texto(palabra_raw)

    if not palabra:
        print("Error: La palabra a codificar está vacía o no tiene letras válidas.")
        return

    # Validar que todos los caracteres de la palabra existan en el texto de referencia
    for char in palabra:
        if char not in probs:
            print(f"Error: El carácter '{char}' no existe en el texto de referencia.")
            return

    # 4. Proceso de Codificación Aritmética
    # Valores iniciales del rango global
    alfa_global = 0.0
    longitud_global = 1.0
    beta_global = 1.0 # Inicialmente 0 + 1

    nombre_archivo = "resultados_aritmetica_2.1.txt"
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        def log(msg=""):
            print(msg)
            f.write(str(msg) + "\n")

        log(f"\nProcesando palabra: '{palabra}'")
        log("=" * 60)

        # Iterar por cada letra de la palabra a codificar
        for i, letra_codificar in enumerate(palabra):
            log(f"\n>>> Procesando letra {i+1}: '{letra_codificar}'")
            log(f"    Rango previo -> Alfa: {alfa_global:.{PRECISION}f} | Longitud: {longitud_global:.{PRECISION}f}")
            log("-" * 85)
            log(f"{'Letra':<6} | {'Probabilidad':<12} | {'Alfa (Inicio)':<18} | {'Longitud':<18} | {'Beta (Fin)':<18}")
            log("-" * 85)

            # Variables para calcular el rango de ESTA iteración
            # Para la primera letra de la lista ordenada, el alfa comienza en el alfa_global actual
            alfa_actual = alfa_global
            
            # Variables para guardar el nuevo rango global cuando encontremos la letra objetivo
            nuevo_alfa_global = alfa_global
            nuevo_longitud_global = longitud_global

            for char in chars_ordenados:
                # 1. Calcular Longitud para este carácter
                # Longitud = Longitud de la anterior letra de la palabra a codificar * Probabilidad base del char
                longitud_char = longitud_global * probs[char]
                
                # 2. Calcular Beta
                # Beta = Alfa + Longitud
                beta_actual = alfa_actual + longitud_char

                # Imprimir fila de la tabla
                log(f"'{char}'    | {probs[char]:.6f}       | {alfa_actual:.{PRECISION}f}       | {longitud_char:.{PRECISION}f}       | {beta_actual:.{PRECISION}f}")

                # Si este es el carácter que estamos codificando, guardamos sus valores para la próxima ronda
                if char == letra_codificar:
                    nuevo_alfa_global = alfa_actual
                    nuevo_longitud_global = longitud_char

                # 3. Preparar Alfa para la siguiente letra en la lista ordenada
                # "Para las demás letras es el valor de beta de la letra anterior"
                alfa_actual = beta_actual

            # Actualizar los globales para la siguiente iteración de la palabra
            alfa_global = nuevo_alfa_global
            longitud_global = nuevo_longitud_global
            log("-" * 85)
            log(f"SELECCIONADO: '{letra_codificar}' -> Nuevo rango: [{alfa_global:.{PRECISION}f}, {alfa_global + longitud_global:.{PRECISION}f})")

        log("\n" + "=" * 60)
        log("RESULTADO FINAL DE LA CODIFICACIÓN")
        log("=" * 60)
        log(f"Palabra: {palabra}")
        log(f"Rango Final (Intervalo):")
        log(f"Límite Inferior (Alfa Final): {alfa_global:.{PRECISION}f}")
        log(f"Límite Superior (Beta Final): {alfa_global + longitud_global:.{PRECISION}f}")
        log(f"Longitud Final              : {longitud_global:.{PRECISION}f}")
        
        # Valor representativo (comúnmente el promedio o el valor más corto en binario dentro del rango)
        valor_codigo = (alfa_global + (alfa_global + longitud_global)) / 2
        log(f"\nValor Codificado (Punto Medio): {valor_codigo:.{PRECISION}f}")

    print(f"\nProceso completado. Resultados guardados en '{nombre_archivo}'.")

if __name__ == "__main__":
    main()