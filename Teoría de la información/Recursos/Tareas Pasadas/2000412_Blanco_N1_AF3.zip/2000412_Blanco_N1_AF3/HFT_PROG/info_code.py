import math
import sys

# Configuración del límite de recursión
sys.setrecursionlimit(2000)

# --- Paso 1: Gestión de entrada (Igual que Huffman) ---
def obtener_texto_usuario():
    """
    Solicita al usuario que ingrese el texto por consola.
    Soporta múltiples líneas.
    """
    print("--- Generador de Códigos Shannon-Fano ---")
    print("Introduce o pega el texto a procesar.")
    print("IMPORTANTE: Al finalizar, presiona Ctrl+D (Mac/Linux) o Ctrl+Z (Windows) para procesar.")
    
    lineas = []
    try:
        while True:
            try:
                linea = input()
                lineas.append(linea)
            except EOFError:
                break
        
        texto = "\n".join(lineas).strip()
        
        if not texto:
            print("Error: El texto no puede estar vacío.")
            sys.exit(1)
        return texto
    except KeyboardInterrupt:
        print("\nOperación cancelada por el usuario.")
        sys.exit(0)

# --- Paso 2: Conteo de frecuencia ---
def contar_caracteres(texto: str) -> list:
    """
    Cuenta frecuencias ignorando espacios en blanco.
    Ordena de MAYOR a MENOR frecuencia, y luego alfabéticamente para desempate.
    """
    contador = {}
    texto = texto.lower()
    for caracter in texto:
        if caracter.isspace():
            continue
            
        if caracter in contador:
            contador[caracter] += 1
        else:
            contador[caracter] = 1

    # Ordenar descendente por frecuencia (-x[1]), luego ascendente por caracter (x[0])
    ordenado = sorted(contador.items(), key=lambda x: (-x[1], x[0]))
    return ordenado

# --- Paso 3: Estructura del Árbol y Algoritmo Shannon-Fano ---

class NodoSF:
    """
    Nodo para el árbol de Shannon-Fano.
    Puede ser un nodo hoja (tiene símbolo) o un nodo interno (tiene hijos).
    """
    def __init__(self, simbolo=None, freq=0, izquierdo=None, derecho=None, es_hoja=False, id_nodo=""):
        self.simbolo = simbolo
        self.freq = freq
        self.izquierdo = izquierdo
        self.derecho = derecho
        self.es_hoja = es_hoja
        self.id_nodo = id_nodo # Identificador para el reporte (ej: Corte 1)

def encontrar_mejor_corte(nodos):
    """
    Encuentra el índice de corte que divide la lista en dos partes
    con la suma de frecuencias más equitativa posible.
    """
    total = sum(n.freq for n in nodos)
    suma_izquierda = 0
    mejor_diff = float('inf')
    mejor_indice = -1

    # Probamos cortar después de cada elemento (excepto el último)
    for i in range(len(nodos) - 1):
        suma_izquierda += nodos[i].freq
        suma_derecha = total - suma_izquierda
        diff = abs(suma_izquierda - suma_derecha)
        
        # Si encontramos una diferencia menor, actualizamos
        # Usamos <= para preferir cortes más balanceados hacia el centro si hay empate,
        # o < para el primero encontrado. < es estándar para este algoritmo greedy.
        if diff < mejor_diff:
            mejor_diff = diff
            mejor_indice = i + 1 # +1 porque el slice excluye el índice final
    
    return mejor_indice, mejor_diff

def construir_shannon_fano(nodos_lista, ht_contribuciones, contador_cortes):
    """
    Función recursiva que divide la lista y construye el árbol.
    """
    # Caso Base: Si solo queda 1 nodo, es una hoja.
    if len(nodos_lista) == 1:
        return nodos_lista[0]

    # Encontrar el punto de corte óptimo
    indice_corte, diff = encontrar_mejor_corte(nodos_lista)
    
    # Dividir listas
    grupo_izq = nodos_lista[:indice_corte]
    grupo_der = nodos_lista[indice_corte:]
    
    # Calcular probabilidades para HT (Entropía del corte)
    # HT = -diff * log2(diff)
    if diff > 0:
        contribucion = -diff * math.log2(diff)
    else:
        contribucion = 0
    
    # Registrar el paso
    id_paso = f"Corte {contador_cortes[0]}"
    ht_contribuciones.append((id_paso, diff, contribucion))
    contador_cortes[0] += 1
    
    # Sumar frecuencias para el nodo padre
    freq_total = sum(n.freq for n in nodos_lista)
    
    # Recursividad
    # Se pasa el mismo contador (lista mutable) para mantener la cuenta global
    hijo_izq = construir_shannon_fano(grupo_izq, ht_contribuciones, contador_cortes)
    hijo_der = construir_shannon_fano(grupo_der, ht_contribuciones, contador_cortes)
    
    # Crear nodo padre
    nodo_padre = NodoSF(freq=freq_total, izquierdo=hijo_izq, derecho=hijo_der, es_hoja=False, id_nodo=id_paso)
    return nodo_padre

def generar_codigos_sf(nodo, codigo_actual, mapa_codigos):
    """
    Recorre el árbol para asignar '0' a la izquierda y '1' a la derecha.
    """
    if nodo is None:
        return
    
    if nodo.es_hoja:
        mapa_codigos[nodo.simbolo] = codigo_actual
        return

    generar_codigos_sf(nodo.izquierdo, codigo_actual + "0", mapa_codigos)
    generar_codigos_sf(nodo.derecho, codigo_actual + "1", mapa_codigos)

def main():
    texto_generado = obtener_texto_usuario()
    frecuencias = contar_caracteres(texto_generado)
    
    if not frecuencias:
        print("Error: Texto sin caracteres válidos.")
        return

    # Preparar datos iniciales
    total_freq = sum(f for _, f in frecuencias)
    
    # Crear nodos hoja iniciales (ordenados por freq descendente)
    nodos_iniciales = [NodoSF(simbolo=s, freq=f/total_freq, es_hoja=True) for s, f in frecuencias]
    
    # Datos para reporte
    datos_reporte = [(n.simbolo, n.freq) for n in nodos_iniciales]

    # --- Archivo de salida ---
    nombre_archivo = "resultados_shannon_fano.txt"
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        def log(msg=""):
            f.write(str(msg) + "\n")

        log("--- Método Shannon-Fano ---")
        log("--- Texto Introducido ---")
        log(texto_generado)
        log("-" * 50)
        
        log("\n--- Frecuencias Ordenadas (Mayor a Menor) ---")
        log(", ".join([f"'{s}':{cnt}" for s, cnt in frecuencias]))
        log("-" * 50)

        log("\n--- Probabilidades Iniciales ---")
        for s, p in datos_reporte:
            log(f"'{s}': {p:.5f}")
        log("-" * 50)

        # Construcción del Árbol
        ht_contribuciones = []
        contador_cortes = [1] # Usamos lista para pasar por referencia
        
        raiz = construir_shannon_fano(nodos_iniciales, ht_contribuciones, contador_cortes)
        
        # Generar Códigos
        codigos_sf = {}
        generar_codigos_sf(raiz, "", codigos_sf)

        log("\n" + "="*50)
        log("                RESULTADOS FINALES")
        log("="*50)

        log("\n--- Códigos Generados (Shannon-Fano) ---")
        # Mostrar en el orden de frecuencia original
        for s, _ in frecuencias:
            log(f"Símbolo: '{s}' | Código: {codigos_sf.get(s, 'N/A')}")
        
        log("\n" + "-"*60)
        log("     PROCESO DE CÁLCULO DE ENTROPÍAS (HE, HT, HIT)")
        log("-"*60)

        # 1. HE (Entropía Fuente)
        log("\n1. HE (Entropía de la Fuente)")
        log("   Fórmula: HE = Σ (-p_i * log2(p_i))")
        
        HE = 0
        terminos_he = []
        for s, p in datos_reporte:
            term = -p * math.log2(p)
            HE += term
            terminos_he.append(f"[-{p:.4f}*log2({p:.4f})]")
        
        log(f"   HE = {' + '.join(terminos_he)}")
        log(f"   HE = {HE:.5f}")

        # 2. HT (Entropía del Árbol - Basada en Cortes)
        log("\n2. HT (Entropía del Árbol / Estructura)")
        log("   Fórmula: HT = Σ (-diff_corte * log2(diff_corte))")
        log("   Nota: Se calcula usando la diferencia absoluta entre las probabilidades de las mitades en cada corte.")
        
        HT = 0
        if not ht_contribuciones:
            log("   HT = 0 (No hubo cortes o diferencias significativas).")
        else:
            pasos_ht = []
            for nombre, diff, contrib in ht_contribuciones:
                HT += contrib
                pasos_ht.append(f"({nombre}: |diff|={diff:.4f} -> {contrib:.4f})")
            
            log(f"   Contribuciones: {', '.join(pasos_ht)}")
            log(f"   HT = {HT:.5f}")

        # 3. HIT
        HIT = HE + HT
        log("\n3. HIT (Entropía de Información Total)")
        log(f"   HIT = {HE:.5f} + {HT:.5f}")
        log(f"   HIT = {HIT:.5f}")

        log("\n" + "-"*50)
        log("     MÉTRICAS DE COMPRESIÓN")
        log("-"*50)

        lme = 8.0
        log(f"LME (Longitud Media Ensamblaje): {lme:.4f} bits")

        lms = sum(p * len(codigos_sf[s]) for s, p in datos_reporte)
        log(f"LMS (Longitud Media Símbolo): {lms:.4f} bits")

        rc = lme / lms if lms != 0 else 0
        log(f"RC (Relación de Compresión): {rc:.4f}")

        log("\n--- RESUMEN FINAL ---")
        log(f"HE  : {HE:.5f}")
        log(f"HT  : {HT:.5f}")
        log(f"HIT : {HIT:.5f}")

    print(f"\nProceso completado.")
    print(f"Resultados guardados en: {nombre_archivo}")

if __name__ == "__main__":
    main()