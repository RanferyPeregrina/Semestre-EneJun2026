import math
import sys

# Configuración del límite de recursión para árboles profundos si el texto es muy largo
sys.setrecursionlimit(2000)

# --- Paso 1: Gestión de entrada ---
def obtener_texto_usuario():
    """
    Solicita al usuario que ingrese el texto por consola.
    Soporta múltiples líneas leyendo hasta EOF (End Of File).
    """
    print("--- Generador de Árbol de Huffman Jerárquico ---")
    print("Introduce o pega el texto a procesar.")
    print("IMPORTANTE: Al finalizar, presiona Ctrl+D (Mac/Linux) o Ctrl+Z (Windows) para procesar.")
    
    lineas = []
    try:
        while True:
            try:
                linea = input()
                lineas.append(linea)
            except EOFError:
                # Se detectó el final de la entrada (Ctrl+D/Z)
                break
        
        texto = "\n".join(lineas).strip()
        
        if not texto:
            print("Error: El texto no puede estar vacío.")
            sys.exit(1)
        return texto
    except KeyboardInterrupt:
        print("\nOperación cancelada por el usuario.")
        sys.exit(0)

# --- Paso 2: Conteo de frecuencia de caracteres ---
def contar_caracteres(texto: str) -> list:
    """
    Cuenta la frecuencia de cada caracter en el texto y lo ordena.
    El orden es: primero por frecuencia descendente, luego por caracter ascendente (alfabético).
    IGNORA TOTALMENTE los espacios en blanco (espacios, saltos de línea, tabulaciones).
    """
    contador = {}
    texto = texto.lower()
    for caracter in texto:
        # Si es un espacio en blanco (espacio, tab, enter), lo saltamos explícitamente
        if caracter.isspace():
            continue
            
        if caracter in contador:
            contador[caracter] += 1
        else:
            contador[caracter] = 1

    # Ordenar por frecuencia (mayor a menor) y luego alfabéticamente para estabilidad
    ordenado = sorted(contador.items(), key=lambda x: (-x[1], x[0]))
    return ordenado

# --- Paso 3: Construcción del Árbol de Huffman ---
class Nodo:
    """
    Clase para representar un nodo en el árbol de Huffman.
    """
    def __init__(self, simbolo, freq, input_order, izquierdo=None, derecho=None, is_generated=False):
        self.simbolo = simbolo
        self.freq = freq
        self.izquierdo = izquierdo
        self.derecho = derecho
        self.input_order = input_order     # Para desempate usando orden de llegada
        self.is_generated = is_generated   # Bandera para saber si es un nodo fusión (s1, s2...) o hoja

def generar_codigos(nodo, codigo_actual, codigos):
    """
    Función recursiva para generar los códigos binarios recorriendo el árbol.
    """
    if nodo is None:
        return
    # Si es un nodo hoja (no generado por fusión), se le asigna un código.
    if not nodo.is_generated:
        codigos[nodo.simbolo] = codigo_actual if codigo_actual else '0' # Caso borde: solo 1 tipo de caracter
    
    # Recorremos hacia la izquierda (1) y derecha (0)
    generar_codigos(nodo.izquierdo, codigo_actual + '1', codigos)
    generar_codigos(nodo.derecho, codigo_actual + '0', codigos)

def main():
    """
    Función principal que integra todo el proceso.
    """
    # 1. Obtener texto desde la terminal
    texto_generado = obtener_texto_usuario()
    
    # 2. Contar frecuencias del texto ingresado (sin espacios)
    frecuencias_contadas = contar_caracteres(texto_generado)
    
    if not frecuencias_contadas:
        print("Error: El texto no contiene caracteres válidos (solo espacios o vacío).")
        return

    # 3. Preparar los datos para el árbol de Huffman
    # Se añade un índice (i) para mantener el orden original de entrada como criterio de desempate
    datos_iniciales = [(simbolo, freq, i) for i, (simbolo, freq) in enumerate(frecuencias_contadas)]

    # --- Apertura del archivo para guardar todos los resultados ---
    nombre_archivo = "resultados_huffman.txt"
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        def log(msg=""):
            # Escribe en el archivo
            f.write(str(msg) + "\n")
        
        log(f"--- Texto Introducido ---")
        log(texto_generado)
        log("-" * 50)

        log("\n--- Frecuencia de caracteres ordenada (Sin espacios) ---")
        log(", ".join([f"'{car}':{cant}" for car, cant in frecuencias_contadas]))
        log("-" * 50)

        frecuencia_total = sum(freq for _, freq, _ in datos_iniciales)
        if frecuencia_total == 0:
            log("Error: La frecuencia total es cero.")
            return
            
        # Crear nodos iniciales (hojas)
        nodos = [Nodo(simbolo, freq / frecuencia_total, order) for simbolo, freq, order in datos_iniciales]
        nodos_hoja = list(nodos) # Copia de respaldo para cálculos finales

        log("\n--- Tabla inicial de símbolos y probabilidades ---")
        # Para mostrar, se ordena por probabilidad descendente
        nodos_ordenados_display = sorted(nodos, key=lambda n: n.freq, reverse=True)
        for nodo in nodos_ordenados_display:
            log(f"'{nodo.simbolo}': {nodo.freq:.5f}")
        log("-" * 50)

        log("\n--- Construcción del Árbol de Huffman (Pasos de Fusión) ---")
        ht_contribuciones = []
        contador_s = 1
        
        # Bucle principal de construcción del árbol
        while len(nodos) > 1:
            # Ordena los nodos por frecuencia ascendente para fusionar los dos menores
            # Criterios: 1. Frecuencia, 2. Si es generado (hojas primero), 3. Orden de entrada inverso
            nodos.sort(key=lambda n: (n.freq, n.is_generated, -n.input_order))
            
            # Extrae los dos nodos con menor frecuencia
            izquierdo = nodos.pop(0)
            derecho = nodos.pop(0)

            # Calcular la contribución a la entropía del árbol (HT)
            # HT se basa en la diferencia de probabilidades entre los nodos fusionados
            if not math.isclose(izquierdo.freq, derecho.freq):
                diferencia = abs(izquierdo.freq - derecho.freq)
                contribucion_ht = -diferencia * math.log2(diferencia) if diferencia > 0 else 0
                ht_contribuciones.append((f"s{contador_s}", diferencia, contribucion_ht))
            
            # Crear el nuevo nodo padre fusionado
            simbolo_padre = f"s{contador_s}"
            freq_padre = izquierdo.freq + derecho.freq
            order_padre = max(izquierdo.input_order, derecho.input_order) # Usamos el orden mayor para desempate futuro
            nodo_padre = Nodo(simbolo_padre, freq_padre, order_padre, izquierdo, derecho, is_generated=True)
            
            log(f"Paso {contador_s}: Uniendo '{izquierdo.simbolo}' ({izquierdo.freq:.4f}) y '{derecho.simbolo}' ({derecho.freq:.4f})")
            log(f"  -> Nuevo nodo '{simbolo_padre}' con probabilidad acumulada: {freq_padre:.4f}\n")
            
            nodos.append(nodo_padre)
            contador_s += 1

        # Generación de códigos
        raiz = nodos[0]
        codigos_huffman = {}
        generar_codigos(raiz, "", codigos_huffman)
        
        log("\n" + "="*50)
        log("                RESULTADOS FINALES")
        log("="*50)

        log("\n--- Códigos de Huffman Generados ---")
        # Muestra los códigos en el orden original de frecuencia
        for simbolo, _, _ in datos_iniciales:
            log(f"Símbolo: '{simbolo}' | Código: {codigos_huffman.get(simbolo, 'N/A')}")

        log("\n" + "-"*60)
        log("     PROCESO DE CÁLCULO DE ENTROPÍAS (HE, HT, HIT)")
        log("-"*60)

        # --- 1. Cálculo de HE (Entropía de la Fuente) ---
        log("\n1. HE (Entropía de la Fuente / Entropía de Shannon)")
        log("   Fórmula: HE = Σ (-p_i * log2(p_i))")
        log("   Donde 'p_i' es la probabilidad de cada símbolo en el mensaje original.")
        log("   Proceso:")
        
        terminos_he_str = []
        HE = 0
        for nodo in nodos_hoja:
            prob = nodo.freq
            if prob > 0:
                term = -prob * math.log2(prob)
                HE += term
                terminos_he_str.append(f"[-{prob:.4f} * log2({prob:.4f})]")
        
        # Mostrar desglose (limitado para no saturar si es muy largo, pero informativo)
        bloque_calculo = " + ".join(terminos_he_str)
        log(f"   HE = {bloque_calculo}")
        log(f"   HE = {HE:.5f}")

        # --- 2. Cálculo de HT (Entropía del Árbol / Jerárquica) ---
        log("\n2. HT (Entropía del Árbol / Estructura)")
        log("   Fórmula: HT = Σ (-d_i * log2(d_i))")
        log("   Donde 'd_i' es la diferencia absoluta de probabilidades (|p_izq - p_der|) en cada paso de fusión.")
        log("   Proceso:")
        
        HT = 0
        if not ht_contribuciones:
             log("   HT = 0 (No hubo diferencias de probabilidad en ninguna fusión).")
        else:
            pasos_ht = []
            for nombre_paso, diferencia, contribucion in ht_contribuciones:
                HT += contribucion
                pasos_ht.append(f"({nombre_paso}: |diff|={diferencia:.4f} -> +{contribucion:.4f})")
            
            # Mostramos las contribuciones individuales
            log(f"   Contribuciones por paso: {', '.join(pasos_ht)}")
            log(f"   HT = Suma de contribuciones")
            log(f"   HT = {HT:.5f}")

        # --- 3. Cálculo de HIT (Entropía de Información Total) ---
        HIT = HE + HT
        log("\n3. HIT (Entropía de Información Total)")
        log("   Fórmula: HIT = HE + HT")
        log(f"   HIT = {HE:.5f} (Fuente) + {HT:.5f} (Árbol)")
        log(f"   HIT = {HIT:.5f}")

        log("\n" + "-"*50)
        log("     MÉTRICAS ADICIONALES DE COMPRESIÓN")
        log("-"*50)

        # LME
        lme = 8.0
        log(f"LME (Longitud Media Ensamblaje): {lme:.4f} bits")
        
        # LMS (Longitud Media de Símbolo) - Longitud promedio ponderada del código Huffman
        lms = sum(nodo.freq * len(codigos_huffman[nodo.simbolo]) for nodo in nodos_hoja)
        log(f"LMS (Longitud Media Símbolo): {lms:.4f} bits")

        # RC
        rc = lme / lms if lms != 0 else 0
        log(f"RC (Relación de Compresión): {rc:.4f}")
        
        # Resumen final
        log("\n--- RESUMEN FINAL ---")
        log(f"HE  : {HE:.5f}")
        log(f"HT  : {HT:.5f}")
        log(f"HIT : {HIT:.5f}")

    print(f"\nProceso completado con éxito.")
    print(f"Los resultados detallados (incluyendo el proceso de cálculo) se han guardado en: {nombre_archivo}")

if __name__ == "__main__":
    main()