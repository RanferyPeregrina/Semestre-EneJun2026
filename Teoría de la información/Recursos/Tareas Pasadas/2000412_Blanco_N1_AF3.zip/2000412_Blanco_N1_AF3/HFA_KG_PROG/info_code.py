import sys
import graphviz

# --- CLASE LOGGER: Para guardar consola en archivo de texto ---
class Logger(object):
    def __init__(self, filename="resultado_huffman_fgk.txt"):
        self.terminal = sys.stdout
        self.log = open(filename, "w", encoding='utf-8')
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
    def flush(self):
        self.terminal.flush()
        self.log.flush()

sys.stdout = Logger()

# --- ESTRUCTURA DEL ÁRBOL FGK ---

class Node:
    def __init__(self, symbol=None, weight=0, order=0, parent=None):
        self.symbol = symbol  # None para nodos internos, carácter para hojas
        self.weight = weight
        self.order = order    # Número de orden (Gallager/Knuth ID)
        self.parent = parent
        self.left = None
        self.right = None
        self.is_nyt = False   # Flag para el nodo NYT (Not Yet Transmitted)

class FGKTree:
    def __init__(self):
        # Inicializamos con el nodo NYT (Not Yet Transmitted)
        self.nyt = Node(weight=0, order=512) # Orden alto arbitrario inicial
        self.nyt.is_nyt = True
        self.root = self.nyt
        self.nodes = [self.nyt] # Lista de todos los nodos para búsquedas rápidas
        self.seen_symbols = {}  # Mapa de símbolo -> Nodo hoja

    def get_code(self, char):
        """Obtiene el camino binario actual para un carácter."""
        if char in self.seen_symbols:
            node = self.seen_symbols[char]
            return self._build_path(node)
        else:
            # Si es nuevo, retorna camino al NYT + código fijo (simulado)
            return self._build_path(self.nyt) + f" [ASC:{ord(char)}]"

    def _build_path(self, node):
        path = ""
        curr = node
        while curr.parent:
            if curr.parent.left == curr:
                path = "0" + path
            else:
                path = "1" + path
            curr = curr.parent
        return path

    def update(self, char):
        """
        Algoritmo FGK de actualización:
        1. Si es nuevo: divide NYT.
        2. Si existe: va al nodo correspondiente.
        3. Incrementa pesos y reordena (swaps) hasta la raíz.
        """
        if char not in self.seen_symbols:
            # === PASO 1: Procesar Símbolo Nuevo (Spawn) ===
            # Convertir el NYT actual en un nodo interno padre
            old_nyt = self.nyt
            
            # Crear nuevo nodo NYT y nuevo nodo Hoja
            # El nuevo nodo interno tendrá peso 1 después del incremento
            # Se asignan hijos: Izquierda=NYT, Derecha=Símbolo (convención común)
            new_nyt = Node(weight=0, parent=old_nyt)
            new_nyt.is_nyt = True
            
            new_symbol_node = Node(symbol=char, weight=1, parent=old_nyt)
            
            old_nyt.is_nyt = False
            old_nyt.left = new_nyt
            old_nyt.right = new_symbol_node
            
            # Actualizar referencias
            self.nyt = new_nyt
            self.seen_symbols[char] = new_symbol_node
            
            # Agregar a la lista de nodos
            self.nodes.append(new_nyt)
            self.nodes.append(new_symbol_node)
            
            # El nodo a incrementar es el padre (old_nyt) que ahora tiene peso 1
            curr = old_nyt
            curr.weight += 1 # Incremento inicial del nuevo subárbol
            curr = curr.parent # Subimos para continuar la validación
        else:
            # === PASO 1 Alternativo: Símbolo Existente ===
            curr = self.seen_symbols[char]

        # === PASO 2: Incrementar y Reordenar (Bubble Up) ===
        while curr:
            # Encontrar el nodo con el mayor 'order' en el bloque del mismo peso
            # (Bloque = nodos con mismo peso). Excluyendo al propio curr y sus padres.
            leader = self._find_block_leader(curr)
            
            if leader and leader != curr and leader != curr.parent:
                print(f"    [SWAP] Intercambiando nodo '{self._n_str(curr)}' con líder '{self._n_str(leader)}' (Peso {curr.weight})")
                self._swap_nodes(curr, leader)
            
            # Incrementar peso
            curr.weight += 1
            curr = curr.parent
        
        # Recalcular órdenes (simple re-numeración para visualización/consistencia)
        self._assign_orders()

    def _find_block_leader(self, node):
        """Busca el nodo con mayor orden que tenga el mismo peso que 'node'."""
        best_node = None
        max_order = -1
        
        # Filtramos nodos con mismo peso
        candidates = [n for n in self.nodes if n.weight == node.weight and n != node]
        
        for cand in candidates:
            # No podemos intercambiar con un ancestro directo (rompería el árbol)
            if cand == node.parent: 
                continue
            
            if cand.order > max_order:
                max_order = cand.order
                best_node = cand
        
        # Solo retornamos líder si su orden es mayor al del nodo actual
        if best_node and best_node.order > node.order:
            return best_node
        return None

    def _swap_nodes(self, node_a, node_b):
        """Intercambia la posición de dos nodos en el árbol (mantiene sus subárboles)."""
        # Intercambiar órdenes (para mantener la propiedad visual)
        node_a.order, node_b.order = node_b.order, node_a.order
        
        # Intercambiar padres e hijos
        # Es complejo: lo más fácil es intercambiar los *contenidos* no estructurales
        # o intercambiar las referencias en los padres.
        
        # Estrategia: Intercambiar padres y posición (left/right)
        pa, pb = node_a.parent, node_b.parent
        
        if pa == pb: # Mismo padre
            pa.left, pa.right = pa.right, pa.left
        else:
            # Identificar si a y b son hijos izq o der
            if pa.left == node_a: pa.left = node_b
            else: pa.right = node_b
            
            if pb.left == node_b: pb.left = node_a
            else: pb.right = node_a
            
            node_a.parent = pb
            node_b.parent = pa

    def _n_str(self, node):
        """String helper para debug."""
        if node.is_nyt: return "NYT"
        if node.symbol: return f"'{node.symbol}'"
        return f"Int(w={node.weight})"

    def _assign_orders(self):
        """
        Reasigna números de orden recorriendo el árbol (Nivel por nivel o post-order inverso).
        Para FGK estándar: De arriba a abajo, derecha a izquierda.
        """
        self.counter = len(self.nodes) + 500
        q = [self.root]
        ordered_list = []
        while q:
            n = q.pop(0)
            ordered_list.append(n)
            # Prioridad derecha luego izquierda para asignar orden mayor a la derecha
            if n.right: q.append(n.right)
            if n.left: q.append(n.left)
        
        # Asignar orden descendente
        for node in ordered_list:
            node.order = self.counter
            self.counter -= 1

# --- VISUALIZACIÓN ---

def visualize_adaptive_tree(tree, filename="huffman_fgk_tree"):
    print(f"\n[INFO] Generando imagen del árbol en '{filename}.png'...")
    dot = graphviz.Digraph(comment='Árbol Huffman Adaptativo (Gallager-Knuth)')
    dot.attr(rankdir='TB')

    def add(node):
        if not node: return
        
        # Estilo del nodo
        lbl = ""
        if node.is_nyt:
            lbl = f"NYT\n({node.weight})"
            fill = "orange"
            shape = "circle"
        elif node.symbol:
            lbl = f"'{node.symbol}'\n({node.weight})"
            fill = "lightblue"
            shape = "circle"
        else:
            lbl = f"{node.weight}"
            fill = "lightgrey"
            shape = "circle"
            
        # ID único
        nid = str(id(node))
        dot.node(nid, label=lbl, style='filled', fillcolor=fill, shape=shape, fontsize="10", width="0.6")

        if node.left:
            dot.edge(nid, str(id(node.left)), label="0")
            add(node.left)
        if node.right:
            dot.edge(nid, str(id(node.right)), label="1")
            add(node.right)

    add(tree.root)
    
    try:
        path = dot.render(filename, format='png', cleanup=True)
        print(f"[ÉXITO] Imagen guardada en: {path}")
    except Exception as e:
        print(f"[ERROR Visualización] {e}")
        print("Código DOT para copiar en viz-js.com:")
        print(dot.source)

# --- EJECUCIÓN PRINCIPAL ---

def run_fgk_simulation(sample):
    print("=== Simulación Huffman Adaptativo (Método Gallager-Knuth) ===")
    print(f"Muestra de entrada: \"{sample}\"\n")
    
    tree = FGKTree()
    
    encoded_stream = []
    
    for i, char in enumerate(sample):
        print(f"--- Paso {i+1}: Procesando '{char}' ---")
        
        # 1. Obtener código PREVIO a la actualización (para transmisión)
        code = tree.get_code(char)
        encoded_stream.append(code)
        print(f"  -> Transmite: {code}")
        
        # 2. Actualizar árbol (Modelo adaptativo)
        tree.update(char)
        
        # Mostrar estructura simple
        print(f"  -> Árbol actualizado. Raíz peso: {tree.root.weight}")

    print("\n=== Resultados Finales ===")
    print(f"Secuencia de códigos transmitidos:")
    print(" | ".join(encoded_stream))
    
    visualize_adaptive_tree(tree)
    print("\n[INFO] Registro guardado en 'resultado_huffman_fgk.txt'")

if __name__ == "__main__":
    sample_text = "c8c426ed"
    run_fgk_simulation(sample_text)