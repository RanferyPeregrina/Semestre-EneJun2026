import sys

# Configuración de precisión para visualización
PRECISION = 10

def limpiar_texto(texto):
    """
    Limpia el texto dejando solo letras de la a-z en minúsculas.
    """
    texto_limpio = []
    for char in texto.lower():
        if char.isalpha():
            texto_limpio.append(char)
    return "".join(texto_limpio)

def obtener_entrada(mensaje):
    """
    Solicita entrada al usuario (multilínea).
    """
    print(f"\n--- {mensaje} ---")
    print("Introduce el texto. Al finalizar, presiona Ctrl+D (Mac/Linux) o Ctrl+Z (Windows).")
    lineas = []
    try:
        while True:
            try:
                linea = input()
                lineas.append(linea)
            except EOFError:
                break
        return "\n".join(lineas).strip()
    except KeyboardInterrupt:
        sys.exit(0)

def inicializar_conteos(texto_referencia):
    """
    Identifica el alfabeto único y asigna un conteo inicial de 1 a cada letra
    (Regla de Laplace básica sugerida en el texto para 'initial counts all 1').
    Retorna:
      - conteos: Diccionario {letra: conteo}
      - orden: Lista de letras ordenadas alfabéticamente (s1...sm)
    """
    # Alfabeto único
    caracteres_unicos = set(texto_referencia)
    caracteres_ordenados = sorted(list(caracteres_unicos))
    
    # Inicializar conteos en 1
    conteos = {char: 1 for char in caracteres_ordenados}
    
    return conteos, caracteres_ordenados

def main():
    print("=== CODIFICACIÓN ARITMÉTICA ADAPTATIVA ===")
    print("Nota: Basado en Sec. 8.3. Los conteos inician en 1 y se actualizan tras cada carácter.")

    # 1. Obtener texto para definir el alfabeto
    texto_ref_raw = obtener_entrada("Paso 1: Definición del Alfabeto (Texto de Referencia)")
    texto_ref = limpiar_texto(texto_ref_raw)
    
    if not texto_ref:
        print("Error: El texto no contiene letras válidas.")
        return

    # 2. Inicializar modelo adaptativo
    conteos, chars_ordenados = inicializar_conteos(texto_ref)

    # 3. Obtener palabra a codificar
    palabra_raw = input("\nIntroduce la palabra a codificar (una sola línea): ").strip()
    palabra = limpiar_texto(palabra_raw)

    if not palabra:
        print("Error: Palabra vacía.")
        return

    # Validar alfabeto
    for char in palabra:
        if char not in conteos:
            print(f"Error: El carácter '{char}' no está en el alfabeto definido.")
            return

    # 4. Proceso Adaptativo
    alfa_global = 0.0
    longitud_global = 1.0
    
    nombre_archivo = "resultados_aritmetica_2.2.txt"
    with open(nombre_archivo, "w", encoding="utf-8") as f:
        def log(msg=""):
            print(msg)
            f.write(str(msg) + "\n")

        log(f"\nProcesando palabra: '{palabra}'")
        log("=" * 80)

        for i, letra_codificar in enumerate(palabra):
            # Calcular total actual (C)
            total_conteos = sum(conteos.values())
            
            # Encabezado de la iteración
            log(f"\n>>> Paso {i+1}: Codificando '{letra_codificar}'")
            log(f"    Estado Actual -> Intervalo Global: [{alfa_global:.{PRECISION}f}, {alfa_global + longitud_global:.{PRECISION}f})")
            log(f"    Conteos Actuales (C={total_conteos}): {conteos}")
            
            log("-" * 100)
            log(f"{'Letra':<6} | {'Conteo':<6} | {'Prob (c/C)':<12} | {'Alfa (Inicio)':<18} | {'Longitud':<18} | {'Beta (Fin)':<18}")
            log("-" * 100)

            alfa_local = alfa_global
            nuevo_alfa = alfa_global
            nuevo_longitud = longitud_global

            # Recorrer el alfabeto ordenado para subdividir el intervalo actual
            for char in chars_ordenados:
                count = conteos[char]
                prob = count / total_conteos  # Probabilidad dinámica c_i / C
                
                # Longitud del subintervalo = Longitud Global * Probabilidad Dinámica
                sub_longitud = longitud_global * prob
                beta_local = alfa_local + sub_longitud

                log(f"'{char}'    | {count:<6} | {prob:.6f}       | {alfa_local:.{PRECISION}f}       | {sub_longitud:.{PRECISION}f}       | {beta_local:.{PRECISION}f}")

                # Si es la letra objetivo, guardamos su subintervalo como el nuevo global
                if char == letra_codificar:
                    nuevo_alfa = alfa_local
                    nuevo_longitud = sub_longitud
                
                # Avanzar alfa para la siguiente letra
                alfa_local = beta_local

            # Actualizar globales
            alfa_global = nuevo_alfa
            longitud_global = nuevo_longitud
            
            # --- PARTE ADAPTATIVA: Actualizar conteos ---
            conteos[letra_codificar] += 1
            log("-" * 100)
            log(f"ACTUALIZACIÓN: Se incrementa conteo de '{letra_codificar}'. Nuevo conteo: {conteos[letra_codificar]}")

        # Resultados Finales
        log("\n" + "=" * 60)
        log("RESULTADO FINAL (ADAPTATIVO)")
        log("=" * 60)
        log(f"Palabra: {palabra}")
        log(f"Conteos Finales: {conteos}")
        log(f"Rango Final: [{alfa_global:.{PRECISION}f}, {alfa_global + longitud_global:.{PRECISION}f})")
        
        valor_codigo = alfa_global + (longitud_global / 2)
        log(f"Valor Codificado (Punto Medio): {valor_codigo:.{PRECISION}f}")

    print(f"\nProceso completado. Resultados guardados en '{nombre_archivo}'.")

if __name__ == "__main__":
    main()