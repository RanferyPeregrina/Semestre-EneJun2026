def main():
    print("Problema: Porcentaje de población SIN acné, peste bubónica ni cólera\n")

    pA = 0.30
    pB = 0.10
    pC = 0.12
    pAB = 0.08
    pAC = 0.07
    pBC = 0.04
    pABC = 0.02

    print("Datos del problema:")
    print(f"  P(Acné)          = {pA:.2f}  (30%)")
    print(f"  P(Peste bubónica)= {pB:.2f}  (10%)")
    print(f"  P(Cólera)        = {pC:.2f}  (12%)")
    print(f"  P(A∩B)           = {pAB:.2f}  (8%)")
    print(f"  P(A∩C)           = {pAC:.2f}  (7%)")
    print(f"  P(B∩C)           = {pBC:.2f}  (4%)")
    print(f"  P(A∩B∩C)         = {pABC:.2f}  (2%)")

    print("\nUsamos el principio de inclusión–exclusión para tres conjuntos:")
    print("  P(A ∪ B ∪ C) = P(A) + P(B) + P(C)")
    print("                 - P(A∩B) - P(A∩C) - P(B∩C)")
    print("                 + P(A∩B∩C)\n")

    suma_individuales = pA + pB + pC
    suma_intersecciones_dos = pAB + pAC + pBC
    union_ABC = suma_individuales - suma_intersecciones_dos + pABC

    print(f"  P(A) + P(B) + P(C) = {pA:.2f} + {pB:.2f} + {pC:.2f} = {suma_individuales:.2f}")
    print(f"  P(A∩B)+P(A∩C)+P(B∩C) = {pAB:.2f} + {pAC:.2f} + {pBC:.2f} = {suma_intersecciones_dos:.2f}")
    print(f"  P(A ∪ B ∪ C) = {suma_individuales:.2f} - {suma_intersecciones_dos:.2f} + {pABC:.2f}")
    print(f"               = {union_ABC:.2f}  ({union_ABC*100:.0f}%)")

    sin_ninguna = 1.0 - union_ABC

    print("\nEl porcentaje SIN ninguna de las tres enfermedades es el complemento de la unión:")
    print("  P(sin ninguna) = 1 - P(A ∪ B ∪ C)")
    print(f"                 = 1 - {union_ABC:.2f} = {sin_ninguna:.2f}")
    print(f"\nRespuesta final: {sin_ninguna*100:.0f}% de la población no padece ninguna de las tres.")

if __name__ == '__main__':
    main()
