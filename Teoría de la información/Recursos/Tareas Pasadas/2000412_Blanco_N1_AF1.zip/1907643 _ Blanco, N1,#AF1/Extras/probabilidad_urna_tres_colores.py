import math

def main():
    print("Problema: Probabilidades en una urna con esferas roja-verde-amarilla\n")

    r = 5
    v = 12
    a = 8
    total = r + v + a

    print("Datos de la urna:")
    print(f"  Rojas    = {r}")
    print(f"  Verdes   = {v}")
    print(f"  Amarillas= {a}")
    print(f"  Total    = {total}\n")

    print("A) Probabilidad de sacar 1 roja, 1 verde y 1 amarilla (en cualquier orden):\n")

    casos_totales = math.comb(total, 3)
    casos_favorables = math.comb(r, 1) * math.comb(v, 1) * math.comb(a, 1)
    pA = casos_favorables / casos_totales

    print(f"Casos totales = C({total}, 3) = {casos_totales}")
    print(f"Casos favorables = C({r},1)*C({v},1)*C({a},1) = {casos_favorables}")
    print(f"P(A) = {casos_favorables}/{casos_totales} = {pA:.5f}")
    print(f"Porcentaje ≈ {pA*100:.2f}%\n")

    print("B) Probabilidad de que la última esfera sea verde:\n")

    pB = v / total
    print(f"Todas las bolas tienen la misma probabilidad de ser la última.")
    print(f"Cantidad de verdes = {v} de {total} totales.")
    print(f"P(última verde) = {v}/{total} = {pB:.5f}")
    print(f"Porcentaje ≈ {pB*100:.2f}%")

if __name__ == "__main__":
    main()
