# Programa para calcular el total de manos con exactamente dos pares rojos

def main():
    # Paso 1: elegir 2 valores distintos para los pares (de 13 posibles)
    valores_de_pares = (13 * 12) // 2   # 78 combinaciones

    # Paso 2: para cada valor, solo hay 1 forma de formar el par rojo (♥ y ♦)
    formas_de_pares_rojos = 1

    # Paso 3: elegir la quinta carta (de los 11 valores restantes, 4 cartas por valor)
    opciones_quinta_carta = 11 * 4  # 44 opciones

    # Resultado total
    total_manos = valores_de_pares * formas_de_pares_rojos * opciones_quinta_carta

    print("Total de manos con exactamente dos pares rojos:", total_manos)


if __name__ == "__main__":
    main()
