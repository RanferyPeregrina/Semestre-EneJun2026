from math import comb

def main():
    print("Problema: 8 lanzamientos de una moneda justa (p=0.5) y número de caras\n")

    n = 8
    p = 0.5
    q = 1 - p
    total = 2**n

    print(f"Datos:")
    print(f"  Número de lanzamientos n = {n}")
    print(f"  Probabilidad de cara p = {p}")
    print(f"  Probabilidad de cruz q = {q}")
    print(f"  Casos equiprobables totales = 2^n = 2^{n} = {total}\n")

    print("A) Probabilidad de que salga exactamente 3 veces cara:\n")

    k = 3
    c = comb(n, k)
    prob_A = c * (p**k) * (q**(n-k))

    print("Usamos la fórmula binomial: P(X = k) = C(n,k) p^k (1-p)^(n-k)")
    print(f"C({n},{k}) = {c}")
    print(f"P(X = {k}) = C({n},{k}) * p^{k} * q^{n-k}")
    print(f"           = {c} * ({p})^{k} * ({q})^{n-k}")
    print(f"           = {c} * ({p**k:.6f}) * ({q**(n-k):.6f})")
    print(f"           = {prob_A:.6f}")
    print(f"Porcentaje ≈ {prob_A*100:.2f}%\n")

    print("B) Probabilidad de que salga al menos 3 veces cara (X ≥ 3):\n")

    prob_B = 0.0
    for k in range(3, n+1):
        c = comb(n, k)
        term = c * (p**k) * (q**(n-k))
        prob_B += term
        print(f"k = {k}: C({n},{k}) = {c}, término = {c} * ({p})^{k} * ({q})^{n-k} = {term:.6f}")

    print(f"\nSuma de términos desde k=3 hasta k={n}:")
    print(f"P(X ≥ 3) = {prob_B:.6f}")
    print(f"Porcentaje ≈ {prob_B*100:.2f}%\n")

    print("C) Probabilidad de que salga a lo mucho 3 veces cara (X ≤ 3):\n")

    prob_C = 0.0
    for k in range(0, 4):
        c = comb(n, k)
        term = c * (p**k) * (q**(n-k))
        prob_C += term
        print(f"k = {k}: C({n},{k}) = {c}, término = {c} * ({p})^{k} * ({q})^{n-k} = {term:.6f}")

    print(f"\nSuma de términos desde k=0 hasta k=3:")
    print(f"P(X ≤ 3) = {prob_C:.6f}")
    print(f"Porcentaje ≈ {prob_C*100:.2f}%")

if __name__ == "__main__":
    main()
