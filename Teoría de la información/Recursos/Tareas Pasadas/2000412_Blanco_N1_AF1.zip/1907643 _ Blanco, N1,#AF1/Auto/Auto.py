import math
from tabulate import tabulate

# Probabilidades relativas de un paso: seguir, derecha, izquierda
p_stay, p_right, p_left = 0.5, 0.3, 0.2
row = [p_stay, p_right, p_left]

logf = math.log  # nats

# Métricas por evento (una fila)
I_vals = [-logf(p) for p in row]
H_i_vals = [p * I for p, I in zip(row, I_vals)]
H_row = sum(H_i_vals)                           # H(D_{t+1} | D_t) por transición (una fila)
sum_I_row = sum(I_vals)

# Construimos la "matriz" de 4 filas idénticas (N,S,E,O)
filas = []
for estado in ["N", "S", "E", "O"]:
    filas.append([estado, "Seguir",    f"{row[0]:.4f}", f"{I_vals[0]:.4f}", f"{H_i_vals[0]:.4f}"])
    filas.append([estado, "Derecha",   f"{row[1]:.4f}", f"{I_vals[1]:.4f}", f"{H_i_vals[1]:.4f}"])
    filas.append([estado, "Izquierda", f"{row[2]:.4f}", f"{I_vals[2]:.4f}", f"{H_i_vals[2]:.4f}"])

# Totales “como en la hoja”
sum_I_total = 4 * sum_I_row
H_total_matrix = 4 * H_row

print("\n=== Giros relativos (Markov 4 direcciones) — nats ===")
print(tabulate(
    filas + [["Σ (por fila)", "", f"{sum(row):.4f}", f"{sum_I_row:.4f}", f"{H_row:.4f}"],
             ["Σ (4 filas)",  "", "—",               f"{sum_I_total:.4f}", f"{H_total_matrix:.4f}"]],
    headers=["Estado", "Evento", "P(E)", "I(E)=-ln P", "H_i(E)"],
    tablefmt="grid"
))

# Entropías marginal y condicional, e información mutua
H_stat = math.log(4.0)                          # H(D_{t+1})
I_mutua = H_stat - H_row                        # por transición

print(f"\nEntropía condicional por transición  H(Dₜ₊₁|Dₜ) = {H_row:.4f} nats/transición")
print(f"Entropía marginal de direcciones     H(Dₜ₊₁)     = {H_stat:.4f} nats")
print(f"Información mutua                   I(Dₜ;Dₜ₊₁)   = {I_mutua:.4f} nats  (~{I_mutua/math.log(2):.3f} bits)")
