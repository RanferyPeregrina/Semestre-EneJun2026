import math
from tabulate import tabulate

# ===============================
# Cálculo para una fila de prob.
# ===============================
def calcular_fila(p_stay, p_right, p_left):
    row = [p_stay, p_right, p_left]
    logf = math.log  # nats

    I_vals = [-logf(p) for p in row]
    H_i_vals = [p * I for p, I in zip(row, I_vals)]
    H_row = sum(H_i_vals)
    sum_I_row = sum(I_vals)

    return row, I_vals, H_i_vals, H_row, sum_I_row


print("\n=== GIROS RELATIVOS (CADENA DE MARKOV) — GENERAL ===")

# Número de direcciones (estados)
n_dirs = int(input("¿Cuántas direcciones (estados) tiene la cadena? (ej. 4) : "))

# Nombres de las direcciones
nombres_input = input(
    "Escribe los nombres de las direcciones separados por comas "
    "(ej. N,S,E,O) o deja vacío para usar N,S,E,O: "
).strip()

if nombres_input == "":
    direcciones = ["N", "S", "E", "O"][:n_dirs]
else:
    direcciones = [d.strip() for d in nombres_input.split(",")]
    direcciones = direcciones[:n_dirs]  # por si escribe más de la cuenta

# Cantidad de giros (transiciones) a considerar
n_giros = int(input("¿Cuántos giros (transiciones) quieres considerar? : "))

print("\nProbabilidades de los eventos desde cada dirección:")
print("NOTA: P(Seguir) + P(Derecha) + P(Izquierda) deben sumar 1.\n")

p_stay = float(input("P(Seguir)    : "))
p_right = float(input("P(Derecha)   : "))
p_left = float(input("P(Izquierda) : "))

# Cálculo de métricas por fila
row, I_vals, H_i_vals, H_row, sum_I_row = calcular_fila(p_stay, p_right, p_left)

# Construimos la “matriz” para todas las direcciones
filas = []
for estado in direcciones:
    filas.append([estado, "Seguir",    f"{row[0]:.4f}", f"{I_vals[0]:.4f}", f"{H_i_vals[0]:.4f}"])
    filas.append([estado, "Derecha",   f"{row[1]:.4f}", f"{I_vals[1]:.4f}", f"{H_i_vals[1]:.4f}"])
    filas.append([estado, "Izquierda", f"{row[2]:.4f}", f"{I_vals[2]:.4f}", f"{H_i_vals[2]:.4f}"])

# Totales como en la hoja, pero con n_dirs en vez de 4 fijo
sum_I_total = n_dirs * sum_I_row
H_total_matrix = n_dirs * H_row

print("\n=== Tabla de probabilidades y contribuciones (nats) ===")
print(
    tabulate(
        filas + [
            ["Σ (por fila)", "", f"{sum(row):.4f}", f"{sum_I_row:.4f}",   f"{H_row:.4f}"],
            [f"Σ ({n_dirs} filas)",  "", "—",               f"{sum_I_total:.4f}", f"{H_total_matrix:.4f}"]
        ],
        headers=["Estado", "Evento", "P(E)", "I(E)=-ln P", "H_i(E)"],
        tablefmt="grid"
    )
)

# Entropías marginal y condicional, e información mutua por transición
H_stat = math.log(float(n_dirs))          # asumimos direcciones equiprobables
I_mutua = H_stat - H_row                  # por transición

print(f"\nEntropía condicional por transición  H(Dₜ₊₁|Dₜ) = {H_row:.4f} nats/transición")
print(f"Entropía marginal de direcciones     H(Dₜ₊₁)     = {H_stat:.4f} nats")
print(f"Información mutua por transición     I(Dₜ;Dₜ₊₁)   = {I_mutua:.4f} nats "
      f"(~{I_mutua/math.log(2):.3f} bits)")

# Si quieres ver el efecto en varios giros:
H_cond_total = n_giros * H_row
I_mutua_total = n_giros * I_mutua

print(f"\nPara {n_giros} giros:")
print(f"  Entropía condicional total  ≈ {H_cond_total:.4f} nats")
print(f"  Info. mutua total aprox.    ≈ {I_mutua_total:.4f} nats "
      f"(~{I_mutua_total/math.log(2):.3f} bits)\n")
