import math
from tabulate import tabulate

# ===============================
# Función general de entropía
# ===============================
def calcular_entropia(probs, simbolos_por_seg=100, base=2):
    if base == 2:
        logf = lambda x: math.log(x, 2)
        unidad = "bits"
        unidad_tasa = "bits/segundo"
    elif base == 10:
        logf = math.log10
        unidad = "hartleys"
        unidad_tasa = "hartleys/segundo"
    else:
        logf = math.log
        unidad = "nats"
        unidad_tasa = "nats/segundo"

    H = 0.0
    filas = []
    for i, p in enumerate(probs, start=1):
        I = -logf(p)
        Hi = p * I
        H += Hi
        filas.append([f"s{i}", f"{p:.5f}", f"{I:.6f}", f"{Hi:.6f}"])
    sumatoria = ["Σ", f"{sum(probs):.5f}", "", f"{H:.6f}"]

    return H, filas, sumatoria, unidad, unidad_tasa, simbolos_por_seg

# ===============================
# Caso 1: Probabilidades dadas
# ===============================
probs_caso1 = [0.30, 0.21, 0.17, 0.13, 0.09, 0.07, 0.01, 0.02]
H1, filas1, sum1, unidad, unidad_tasa, sps = calcular_entropia(probs_caso1)

print("\n=== CASO 1: Probabilidades dadas ===")
print(tabulate(filas1 + [sum1], headers=["Símbolo", "P(s)", f"I(s)=-log2 P(s)", "H_i(s)"], tablefmt="grid"))
print(f"Entropía total H = {H1:.6f} {unidad}/símbolo")
print(f"Tasa de información R = {H1 * sps:.6f} {unidad_tasa}")
print("Información mutua entre símbolos consecutivos: 0 (fuente sin memoria)")

# ===============================
# Caso 2: Equiprobable con 8 símbolos
# ===============================
probs_caso2 = [1/8]*8
H2, filas2, sum2, unidad, unidad_tasa, sps = calcular_entropia(probs_caso2)

print("\n=== CASO 2: 8 símbolos equiprobables ===")
print(tabulate(filas2 + [sum2], headers=["Símbolo", "P(s)", f"I(s)=-log2 P(s)", "H_i(s)"], tablefmt="grid"))
print(f"Entropía total H = {H2:.6f} {unidad}/símbolo")
print(f"Tasa de información R = {H2 * sps:.6f} {unidad_tasa}")
print("Información mutua entre símbolos consecutivos: 0 (fuente sin memoria)\n")
