import math
from tabulate import tabulate

# ===============================
# Función general de entropía
# ===============================
def calcular_entropia(probs, simbolos_por_seg=100, base=2):
    if base == 2:
        logf = lambda x: math.log(x, 2)
        unidad = "bits"
        unidad_tasa = "bits/segundo"
    elif base == 10:
        logf = math.log10
        unidad = "hartleys"
        unidad_tasa = "hartleys/segundo"
    else:
        logf = math.log
        unidad = "nats"
        unidad_tasa = "nats/segundo"

    H = 0.0
    filas = []
    for i, p in enumerate(probs, start=1):
        I = -logf(p)
        Hi = p * I
        H += Hi
        filas.append([f"s{i}", f"{p:.5f}", f"{I:.6f}", f"{Hi:.6f}"])
    sumatoria = ["Σ", f"{sum(probs):.5f}", "", f"{H:.6f}"]

    return H, filas, sumatoria, unidad, unidad_tasa, simbolos_por_seg


print("\n=== CÁLCULO DE ENTROPÍA GENERALIZADO ===")

n = int(input("¿Cuántos símbolos tiene la fuente? "))

modo = input("¿Deseas probabilidades manuales (M) o equiprobables (E)? ").lower()

if modo == "e":
    probs = [1/n] * n
else:
    print("\nIngresa las probabilidades una por una (deben sumar 1):")
    probs = []
    for i in range(n):
        p = float(input(f"P(s{i+1}): "))
        probs.append(p)

base = int(input("\nBase logarítmica (2 para bits, 10 para hartleys, otro = nats): "))
sps = float(input("Símbolos por segundo (default 100): ") or 100)

H, filas, sumatoria, unidad, unidad_tasa, simbolos_por_seg = calcular_entropia(
    probs, simbolos_por_seg=sps, base=base
)

print("\n=== RESULTADOS ===")
print(tabulate(filas + [sumatoria],
               headers=["Símbolo", "P(s)", f"I(s)=-log P(s)", "H_i(s)"],
               tablefmt="grid"))

print(f"\nEntropía total H = {H:.6f} {unidad}/símbolo")
print(f"Tasa de información R = {H * sps:.6f} {unidad_tasa}")
print("Información mutua entre símbolos consecutivos: 0 (fuente sin memoria)\n")
