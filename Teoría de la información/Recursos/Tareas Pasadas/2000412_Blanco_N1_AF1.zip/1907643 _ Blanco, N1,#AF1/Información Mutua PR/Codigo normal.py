import math
from tabulate import tabulate

def parse_number(s):
    s = s.strip()
    if "/" in s:
        num, den = s.split("/")
        return float(num) / float(den)
    return float(s)

def ask_float(prompt):
    while True:
        try:
            return parse_number(input(prompt))
        except ValueError:
            print("Entrada inválida, intenta de nuevo.")

def ask_int(prompt, min_value=1):
    while True:
        try:
            v = int(input(prompt))
            if v < min_value:
                print("Debe ser al menos", min_value)
            else:
                return v
        except ValueError:
            print("Entrada inválida, intenta de nuevo.")

def choose_base():
    print("Elige base para los logaritmos:")
    print("1) 2  (bits)")
    print("2) 10 (hartleys)")
    print("3) e  (nats)")
    print("4) Otra base")
    while True:
        op = input("Opción: ").strip()
        if op == "1":
            return 2.0, "bits"
        elif op == "2":
            return 10.0, "hartleys"
        elif op == "3":
            return math.e, "nats"
        elif op == "4":
            b = ask_float("Ingresa la base (>1): ")
            if b <= 1:
                print("La base debe ser > 1.")
            else:
                return b, f"log-base-{b}"
        else:
            print("Opción inválida.")

def self_information(p, base):
    if p <= 0:
        return 0.0
    return -math.log(p, base)

def entropy_from_probs(probs, base):
    h = 0.0
    for p in probs:
        if p > 0:
            h += p * self_information(p, base)
    return h

def normalize_distribution(joint_dict):
    total = sum(joint_dict.values())
    if total <= 0:
        raise ValueError("La suma total de probabilidades es <= 0.")
    if abs(total - 1.0) > 1e-6:
        print(f"Advertencia: la suma de probabilidades es {total:.6f}, se normalizará a 1.")
        factor = 1.0 / total
        for k in joint_dict:
            joint_dict[k] *= factor
    return joint_dict

def input_mode_menu():
    print("¿Cómo deseas ingresar la distribución conjunta P(X,Y)?")
    print("1) Matriz explícita de P(x,y)")
    print("2) Eventos equiprobables (todas las salidas igual probables)")
    print("3) Lista de eventos (x,y) con su probabilidad")
    while True:
        op = input("Opción: ").strip()
        if op in ("1", "2", "3"):
            return op
        print("Opción inválida.")

def input_joint_matrix():
    nx = ask_int("Número de valores distintos de X: ")
    ny = ask_int("Número de valores distintos de Y: ")
    x_labels = input("Nombres de los valores de X separados por comas (o vacío para X1,...): ").strip()
    if x_labels:
        xs = [v.strip() for v in x_labels.split(",")]
        if len(xs) != nx:
            print("El número de nombres no coincide, se usará X1,...,Xn.")
            xs = [f"X{i+1}" for i in range(nx)]
    else:
        xs = [f"X{i+1}" for i in range(nx)]
    y_labels = input("Nombres de los valores de Y separados por comas (o vacío para Y1,...): ").strip()
    if y_labels:
        ys = [v.strip() for v in y_labels.split(",")]
        if len(ys) != ny:
            print("El número de nombres no coincide, se usará Y1,...,Yn.")
            ys = [f"Y{i+1}" for i in range(ny)]
    else:
        ys = [f"Y{i+1}" for i in range(ny)]
    joint = {}
    print("Ingresa P(x,y) para cada par (X,Y). Puedes usar decimales o fracciones como 1/6.")
    for x in xs:
        for y in ys:
            p = ask_float(f"P({x},{y}) = ")
            joint[(x, y)] = p
    normalize_distribution(joint)
    return xs, ys, joint

def input_equiprobable_mapping():
    n = ask_int("Número de resultados equiprobables (microestados): ")
    print("Para cada resultado, indica a qué valor de X y Y corresponde.")
    joint = {}
    xs_order = []
    ys_order = []
    for i in range(n):
        x = input(f"Resultado {i+1}: valor de X = ").strip()
        y = input(f"Resultado {i+1}: valor de Y = ").strip()
        if x not in xs_order:
            xs_order.append(x)
        if y not in ys_order:
            ys_order.append(y)
        joint[(x, y)] = joint.get((x, y), 0.0) + 1.0
    for k in joint:
        joint[k] /= n
    return xs_order, ys_order, joint

def input_explicit_event_list():
    k = ask_int("Número de eventos conjuntos distintos (x,y) con probabilidad: ")
    joint = {}
    xs_order = []
    ys_order = []
    for i in range(k):
        print(f"Evento {i+1}:")
        x = input("  Valor de X: ").strip()
        y = input("  Valor de Y: ").strip()
        p = ask_float("  Probabilidad de este (x,y): ")
        if x not in xs_order:
            xs_order.append(x)
        if y not in ys_order:
            ys_order.append(y)
        joint[(x, y)] = joint.get((x, y), 0.0) + p
    normalize_distribution(joint)
    return xs_order, ys_order, joint

def build_joint_matrix(xs, ys, joint_dict):
    matrix = []
    for x in xs:
        row = []
        for y in ys:
            row.append(joint_dict.get((x, y), 0.0))
        matrix.append(row)
    return matrix

def compute_marginals(xs, ys, pxy):
    px = {}
    py = {}
    for i, x in enumerate(xs):
        s = 0.0
        for j in range(len(ys)):
            s += pxy[i][j]
        px[x] = s
    for j, y in enumerate(ys):
        s = 0.0
        for i in range(len(xs)):
            s += pxy[i][j]
        py[y] = s
    return px, py

def print_joint_table(xs, ys, pxy, base, units):
    rows = []
    for i, x in enumerate(xs):
        for j, y in enumerate(ys):
            p = pxy[i][j]
            if p > 0:
                info = self_information(p, base)
                contrib = p * info
            else:
                info = 0.0
                contrib = 0.0
            rows.append([x, y, f"{p:.6f}", f"{info:.6f}", f"{contrib:.6f}"])
    print("\n=== Tabla conjunta P(X,Y) ===")
    headers = ["X", "Y", "P(x,y)", f"I(x,y) [{units}]", f"H_i(x,y) [{units}]"]
    print(tabulate(rows, headers=headers, tablefmt="github"))

def print_marginal_table(label_var, labels, pdict, base, units):
    rows = []
    for v in labels:
        p = pdict[v]
        if p > 0:
            info = self_information(p, base)
            contrib = p * info
        else:
            info = 0.0
            contrib = 0.0
        rows.append([v, f"{p:.6f}", f"{info:.6f}", f"{contrib:.6f}"])
    print(f"\n=== Tabla marginal P({label_var}) ===")
    headers = [label_var, f"P({label_var.lower()})", f"I({label_var.lower()}) [{units}]", f"H_i({label_var.lower()}) [{units}]"]
    print(tabulate(rows, headers=headers, tablefmt="github"))

def check_independence(xs, ys, pxy, px, py):
    max_diff = 0.0
    for i, x in enumerate(xs):
        for j, y in enumerate(ys):
            p = pxy[i][j]
            q = px[x] * py[y]
            diff = abs(p - q)
            if diff > max_diff:
                max_diff = diff
    return max_diff

def main():
    print("=====================================")
    print("  ANALIZADOR GENERAL DE I(X;Y)       ")
    print("  ENTROPIAS Y INFORMACION MUTUA      ")
    print("=====================================\n")
    base, units = choose_base()
    while True:
        mode = input_mode_menu()
        if mode == "1":
            xs, ys, joint = input_joint_matrix()
        elif mode == "2":
            xs, ys, joint = input_equiprobable_mapping()
        else:
            xs, ys, joint = input_explicit_event_list()
        pxy = build_joint_matrix(xs, ys, joint)
        px, py = compute_marginals(xs, ys, pxy)
        print_joint_table(xs, ys, pxy, base, units)
        print_marginal_table("X", xs, px, base, units)
        print_marginal_table("Y", ys, py, base, units)
        h_x = entropy_from_probs([px[x] for x in xs], base)
        h_y = entropy_from_probs([py[y] for y in ys], base)
        h_xy = 0.0
        for i in range(len(xs)):
            for j in range(len(ys)):
                p = pxy[i][j]
                if p > 0:
                    h_xy += p * self_information(p, base)
        i_xy = h_x + h_y - h_xy
        h_x_given_y = h_xy - h_y
        h_y_given_x = h_xy - h_x
        print("\n=== Resultados globales ===")
        print(f"H(X)      = {h_x:.6f} {units}")
        print(f"H(Y)      = {h_y:.6f} {units}")
        print(f"H(X,Y)    = {h_xy:.6f} {units}")
        print(f"H(X|Y)    = {h_x_given_y:.6f} {units}")
        print(f"H(Y|X)    = {h_y_given_x:.6f} {units}")
        print(f"I(X;Y)    = {i_xy:.6f} {units}")
        max_diff = check_independence(xs, ys, pxy, px, py)
        print(f"\nMáx |P(x,y) - P(x)P(y)| = {max_diff:.6e}")
        if max_diff < 1e-10:
            print("Conclusión aproximada: X e Y son prácticamente independientes.")
        else:
            print("Conclusión aproximada: X e Y NO son independientes.")
        again = input("\n¿Analizar otro par de variables? (s/n): ").strip().lower()
        if again != "s":
            print("\nFin del programa.")
            break

if __name__ == "__main__":
    main()
