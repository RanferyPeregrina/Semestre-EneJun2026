import math
from itertools import product
from tabulate import tabulate

# --------------------------
# Punto A: Lanzar dos dados (suma)
# --------------------------
def tabla_dos_dados_suma():
    mult = {2:1, 3:2, 4:3, 5:4, 6:5, 7:6, 8:5, 9:4, 10:3, 11:2, 12:1}
    total = 36
    tabla = []
    sum_m, sum_p, sum_I, sum_Hi = 0, 0, 0, 0

    for n in range(2, 13):
        m = mult[n]
        p = m / total
        I = -math.log10(p)              # hartleys
        H_i = p * I
        tabla.append([n, m, f"{p:.5f}", f"{I:.6f}", f"{H_i:.6f}"])
        sum_m += m
        sum_p += p
        sum_I += I
        sum_Hi += H_i

    # Fila de sumatoria
    tabla.append(["Σ", sum_m, f"{sum_p:.5f}", f"{sum_I:.6f}", f"{sum_Hi:.6f}"])

    print("\n=== Punto A: Lanzar dos dados (suma) ===")
    print(tabulate(tabla, headers=["n", "multiplicidad", "P(E)", "I(E)=-log P(E)", "H_i(E)"], tablefmt="grid"))
    print(f"\n Entropía total H(A) = {sum_Hi:.6f} hartleys\n")

# --------------------------
# Punto B: Lanzar dos dados de distinto color
# --------------------------
def tabla_dos_dados_colores():
    total = 36
    p = 1/36
    I = -math.log10(p)
    H_i = p * I
    tabla = []
    sum_m, sum_p, sum_I, sum_Hi = 0, 0, 0, 0

    for d1, d2 in product(range(1,7), repeat=2):
        tabla.append([d1, d2, f"{p:.5f}", f"{I:.6f}", f"{H_i:.6f}"])
        sum_m += 1
        sum_p += p
        sum_I += I
        sum_Hi += H_i

    # Fila de sumatoria
    tabla.append(["Σ", "Σ", f"{sum_p:.5f}", f"{sum_I:.6f}", f"{sum_Hi:.6f}"])

    print("\n=== Punto B: Dos dados de distinto color ===")
    print(tabulate(tabla, headers=["Dado1", "Dado2", "P(E)", "I(E)", "H_i(E)"], tablefmt="grid"))
    print(f"\n Entropía total H(B) = {sum_Hi:.6f} hartleys\n")

# Ejecutar
if __name__ == "__main__":
    tabla_dos_dados_suma()
    tabla_dos_dados_colores()
