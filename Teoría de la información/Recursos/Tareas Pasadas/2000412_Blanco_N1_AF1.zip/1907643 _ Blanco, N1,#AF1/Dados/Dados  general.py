import math
from itertools import product
from tabulate import tabulate

# ==========================
# Funciones auxiliares
# ==========================

def elegir_base():
    msg = "Elige base del log (2=bits, 10=hartleys, e=nats) [10]: "
    s = input(msg).strip().lower()
    if s in ("2", "base2", "bits"):
        return (lambda x: math.log(x, 2)), "bits"
    if s in ("e", "nat", "nats"):
        return math.log, "nats"
    return math.log10, "hartleys"

def imprimir_tabla(headers, filas, sumatoria, H_total, unidad):
    filas_con_sum = filas + [sumatoria]
    print(tabulate(filas_con_sum, headers=headers, tablefmt="grid"))
    print(f"\nEntropía total H = {H_total:.6f} {unidad}")

# ==========================
# Métodos
# ==========================

def metodo_pares(num_dados, logf, unidad):
    caras = 6  # por defecto
    total = caras**num_dados
    p = 1/total
    I = -logf(p)
    H_i = p*I

    filas = []
    sum_p = sum_I = sum_Hi = 0.0
    for evento in product(range(1, caras+1), repeat=num_dados):
        filas.append([evento, f"{p:.5f}", f"{I:.6f}", f"{H_i:.6f}"])
        sum_p += p; sum_I += I; sum_Hi += H_i

    sumatoria = ["Σ", f"{sum_p:.5f}", f"{sum_I:.6f}", f"{sum_Hi:.6f}"]
    print(f"\n=== Método: Pares ordenados con {num_dados} dado(s) de 6 caras ===")
    imprimir_tabla(["Evento", "P(E)", "I(E)", "H_i(E)"], filas, sumatoria, sum_Hi, unidad)

    # Resumen adicional: entropías por dado y conjunta; I entre dados
    H_marginal_dado = -6*(1/6)*logf(1/6)  # = logf(6)
    H_conjunta = num_dados * H_marginal_dado
    print(f"H(dado) = {H_marginal_dado:.6f} {unidad}  |  H(d1,...,d{num_dados}) = {H_conjunta:.6f} {unidad}")
    if num_dados >= 2:
        print("Información mutua entre cualesquiera dos dados: I(d_i; d_j) = 0")
    print()

def metodo_suma(num_dados, logf, unidad):
    caras = 6
    total = caras**num_dados

    # multiplicidades por suma
    mult = {}
    for evento in product(range(1, caras+1), repeat=num_dados):
        s = sum(evento)
        mult[s] = mult.get(s, 0) + 1

    filas = []
    sum_m = sum_p = sum_I = sum_Hi = 0.0
    for s, m in sorted(mult.items()):
        p = m/total
        I = -logf(p)
        H_i = p*I
        filas.append([s, m, f"{p:.5f}", f"{I:.6f}", f"{H_i:.6f}"])
        sum_m += m; sum_p += p; sum_I += I; sum_Hi += H_i

    sumatoria = ["Σ", int(sum_m), f"{sum_p:.5f}", f"{sum_I:.6f}", f"{sum_Hi:.6f}"]
    print(f"\n=== Método: Suma de {num_dados} dado(s) de 6 caras ===")
    imprimir_tabla(["Suma", "Multiplicidad", "P(E)", "I(E)", "H_i(E)"], filas, sumatoria, sum_Hi, unidad)

    # Resumen adicional: nota sobre información mutua entre dados (modelo independiente)
    if num_dados >= 2:
        print("Información mutua entre dados (modelo subyacente independiente): I(d_i; d_j) = 0")
    # Comentario útil (no se imprime numéricamente): I((d1,...,dn); S) = H(S)
    print("(Nota) I((d1,...,dn); S) = H(S), porque S es función determinista del vector de dados.\n")

# ==========================
# Menú principal
# ==========================

def main():
    while True:
        print("\n===== MENÚ GENERAL DE DADOS (6 caras) =====")
        print("1) Pares ordenados (eventos equiprobables)")
        print("2) Suma de los dados")
        print("0) Salir")
        op = input("Elige una opción: ").strip()
        if op == "0":
            break
        num_dados = int(input("¿Cuántos dados lanzar? ").strip())
        logf, unidad = elegir_base()

        if op == "1":
            metodo_pares(num_dados, logf, unidad)
        elif op == "2":
            metodo_suma(num_dados, logf, unidad)
        else:
            print("Opción inválida.")

if __name__ == "__main__":
    main()
