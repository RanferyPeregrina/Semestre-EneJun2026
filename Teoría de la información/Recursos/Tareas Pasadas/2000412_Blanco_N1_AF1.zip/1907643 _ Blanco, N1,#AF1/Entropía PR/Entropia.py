import math
from tabulate import tabulate

def parse_number(s):
    s = s.strip()
    if "/" in s:
        num, den = s.split("/")
        return float(num) / float(den)
    return float(s)

def ask_float(prompt):
    while True:
        try:
            return parse_number(input(prompt))
        except ValueError:
            print("Entrada inválida, intenta de nuevo.")

def ask_int(prompt, minimum=1):
    while True:
        try:
            v = int(input(prompt))
            if v < minimum:
                print("Debe ser al menos", minimum)
            else:
                return v
        except ValueError:
            print("Entrada inválida, intenta de nuevo.")

def choose_base():
    print("Elige base para los logaritmos:")
    print("1) 2  (bits)")
    print("2) 10 (hartleys)")
    print("3) e  (nats)")
    print("4) Otra base")
    while True:
        op = input("Opción: ").strip()
        if op == "1":
            return 2.0, "bits"
        if op == "2":
            return 10.0, "hartleys"
        if op == "3":
            return math.e, "nats"
        if op == "4":
            b = ask_float("Ingresa la base (>1): ")
            if b <= 1:
                print("La base debe ser > 1.")
            else:
                return b, f"log-base-{b}"
        print("Opción inválida.")

def self_information(p, base):
    if p <= 0:
        return 0.0
    return -math.log(p, base)

def entropy_from_probs(probs, base):
    h = 0.0
    for p in probs:
        if p > 0:
            h += p * self_information(p, base)
    return h

def normalize_probs(labels, probs):
    total = sum(probs)
    if total <= 0:
        raise ValueError("La suma total de probabilidades es <= 0.")
    if abs(total - 1.0) > 1e-6:
        print(f"Advertencia: la suma de probabilidades es {total:.6f}, se normalizará a 1.")
        factor = 1.0 / total
        probs = [p * factor for p in probs]
    return labels, probs

def input_probs_direct():
    n = ask_int("Número de símbolos distintos: ")
    names = input("Nombres de los símbolos separados por comas (vacío para S1,...,Sn): ").strip()
    if names:
        symbols = [v.strip() for v in names.split(",")]
        if len(symbols) != n:
            print("El número de nombres no coincide, se usará S1,...,Sn.")
            symbols = [f"S{i+1}" for i in range(n)]
    else:
        symbols = [f"S{i+1}" for i in range(n)]
    probs = []
    print("Ingresa P(s) para cada símbolo. Puedes usar decimales o fracciones como 1/8.")
    for s in symbols:
        p = ask_float(f"P({s}) = ")
        probs.append(p)
    symbols, probs = normalize_probs(symbols, probs)
    return symbols, probs

def input_equiprobable():
    n = ask_int("Número de símbolos equiprobables: ")
    names = input("Nombres de los símbolos separados por comas (vacío para S1,...,Sn): ").strip()
    if names:
        symbols = [v.strip() for v in names.split(",")]
        if len(symbols) != n:
            print("El número de nombres no coincide, se usará S1,...,Sn.")
            symbols = [f"S{i+1}" for i in range(n)]
    else:
        symbols = [f"S{i+1}" for i in range(n)]
    p = 1.0 / n
    probs = [p for _ in range(n)]
    return symbols, probs

def input_from_counts():
    n = ask_int("Número de símbolos distintos: ")
    names = input("Nombres de los símbolos separados por comas (vacío para S1,...,Sn): ").strip()
    if names:
        symbols = [v.strip() for v in names.split(",")]
        if len(symbols) != n:
            print("El número de nombres no coincide, se usará S1,...,Sn.")
            symbols = [f"S{i+1}" for i in range(n)]
    else:
        symbols = [f"S{i+1}" for i in range(n)]
    counts = []
    print("Ingresa el número de casos favorables (multiplicidad) para cada símbolo.")
    for s in symbols:
        c = ask_float(f"Conteo de {s} = ")
        counts.append(c)
    total = sum(counts)
    if total <= 0:
        raise ValueError("La suma de conteos es <= 0.")
    probs = [c / total for c in counts]
    return symbols, probs

def mode_menu():
    print("\n¿Cómo quieres definir la distribución de la variable?")
    print("1) Probabilidades P(s) dadas directamente")
    print("2) Símbolos equiprobables")
    print("3) A partir de conteos/multiplicidades")
    print("4) Salir")
    while True:
        op = input("Opción: ").strip()
        if op in ("1", "2", "3", "4"):
            return op
        print("Opción inválida.")

def print_entropy_table(symbols, probs, base, units):
    rows = []
    for s, p in zip(symbols, probs):
        if p > 0:
            info = self_information(p, base)
            contrib = p * info
        else:
            info = 0.0
            contrib = 0.0
        rows.append([s, f"{p:.6f}", f"{info:.6f}", f"{contrib:.6f}"])
    print("\n=== Tabla de la variable aleatoria ===")
    headers = ["Símbolo", "P(s)", f"I(s) [{units}]", f"H_i(s) [{units}]"]
    print(tabulate(rows, headers=headers, tablefmt="github"))

def main():
    print("========================================")
    print("  ANALIZADOR GENERAL DE ENTROPÍA H(X)   ")
    print("========================================\n")
    base, units = choose_base()
    while True:
        op = mode_menu()
        if op == "4":
            print("\nFin del programa.")
            break
        if op == "1":
            symbols, probs = input_probs_direct()
        elif op == "2":
            symbols, probs = input_equiprobable()
        else:
            symbols, probs = input_from_counts()
        print_entropy_table(symbols, probs, base, units)
        h = entropy_from_probs(probs, base)
        print("\n=== Cálculo de entropía ===")
        print("Fórmulas teóricas:")
        print("  I(s)   = -log_b(P(s))")
        print("  H(X)   = Σ_s P(s) I(s)")
        print(f"\nResultado numérico:")
        print(f"  H(X)   = {h:.6f} {units}")
        ans = input("\n¿Quieres calcular la tasa de información de una fuente con esta distribución? (s/n): ").strip().lower()
        if ans == "s":
            r = ask_float("Símbolos por segundo (r): ")
            rate = h * r
            print(f"  R = H(X) * r = {h:.6f} * {r:.6f} = {rate:.6f} {units}/s")
        again = input("\n¿Analizar otra distribución? (s/n): ").strip().lower()
        if again != "s":
            print("\nFin del programa.")
            break

if __name__ == "__main__":
    main()
