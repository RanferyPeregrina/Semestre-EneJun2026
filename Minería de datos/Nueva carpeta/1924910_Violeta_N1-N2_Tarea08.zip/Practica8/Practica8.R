# Practica 8 - Analisis predictivo
# Librerias
paquetes <- c(
  "lmtest",
  "MASS",
  "glmnet",
  "car",
  "nnet",
  "class",
  "dplyr",
  "randomForest"
)
for (p in paquetes) {
  if (!require(p, character.only = TRUE)) {
    install.packages(p)
    library(p, character.only = TRUE)
  }
}
set.seed(42)
# 2. Carga del archivo old (1).csv
datos_old <- read.csv("old (1).csv")
head(datos_old)
str(datos_old)
summary(datos_old)
# 3. Regresion lineal simple
# Variable dependiente: waiting, Variable independiente: eruptions
modelo_simple <- lm(waiting ~ eruptions, data = datos_old)
summary(modelo_simple)
# Grafica de regresion lineal simple
png("figura_1_regresion_lineal_simple.png", width = 900, height = 650)
plot(
  datos_old$eruptions,
  datos_old$waiting,
  main = "Regresión Lineal Simple",
  xlab = "Duración de la erupción",
  ylab = "Tiempo de espera",
  pch = 16
)
abline(modelo_simple, lwd = 2)
dev.off()
# 4. Prueba de Breusch-Pagan
prueba_bp <- bptest(modelo_simple)
prueba_bp
# 5. Regresion lineal simple con predictor binario
# Dataset: mtcars, Variable dependiente: mpg, Predictor binario: am
datos_mtcars <- mtcars
modelo_binario <- lm(mpg ~ am, data = datos_mtcars)
summary(modelo_binario)
t.test(mpg ~ am, data = datos_mtcars, var.equal = TRUE)
datos_mtcars$automatic <- ifelse(datos_mtcars$am == 0, "yes", "no")
modelo_binario_factor <- lm(mpg ~ factor(automatic), data = datos_mtcars)
modelo_binario_factor
summary(modelo_binario_factor)
# 6. Se carga del archivo precio.csv
datos_precio <- read.csv("precio.csv")
head(datos_precio)
str(datos_precio)
summary(datos_precio)
datos_precio <- na.omit(datos_precio)
# 7. Regresion multiple
# Variable dependiente: precio    Predictores: tcons, recamaras, condicion
modelo_multiple <- lm(
  precio ~ tcons + recamaras + condicion,
  data = datos_precio
)
summary(modelo_multiple)
nuevo_dato <- data.frame(
  tcons = 130,
  recamaras = 3,
  condicion = 4
)
prediccion_multiple <- predict(modelo_multiple, nuevo_dato)
prediccion_multiple
# 8. Modelo Kitchen Sink
# Se incluyen todas las variables predictoras disponibles
modelo_kitchen <- lm(precio ~ ., data = datos_precio)
summary(modelo_kitchen)
# 9. Regresion Stepwise con AIC
modelo_stepwise <- stepAIC(
  modelo_kitchen,
  direction = "both",
  trace = FALSE
)
summary(modelo_stepwise)
# 10. Regresion Lasso
x_lasso <- model.matrix(precio ~ ., data = datos_precio)[, -1]
y_lasso <- datos_precio$precio
modelo_lasso <- glmnet(
  x_lasso,
  y_lasso,
  alpha = 1
)
cv_lasso <- cv.glmnet(
  x_lasso,
  y_lasso,
  alpha = 1
)
mejor_lambda_lasso <- cv_lasso$lambda.min
mejor_lambda_lasso
coeficientes_lasso <- coef(modelo_lasso, s = mejor_lambda_lasso)
coeficientes_lasso
predicciones_lasso <- predict(
  modelo_lasso,
  newx = x_lasso,
  s = mejor_lambda_lasso
)
mse_lasso <- mean((datos_precio$precio - predicciones_lasso)^2)
mse_lasso
coef_lasso_df <- as.data.frame(as.matrix(coeficientes_lasso))
coef_lasso_df$Variable <- rownames(coef_lasso_df)
colnames(coef_lasso_df)[1] <- "Coeficiente"
coef_lasso_df <- coef_lasso_df[, c("Variable", "Coeficiente")]
write.csv(
  coef_lasso_df,
  "coeficientes_lasso.csv",
  row.names = FALSE
)
# 11. Regresion Ridge
x_ridge <- model.matrix(precio ~ ., data = datos_precio)[, -1]
y_ridge <- datos_precio$precio
modelo_ridge <- glmnet(
  x_ridge,
  y_ridge,
  alpha = 0
)
cv_ridge <- cv.glmnet(
  x_ridge,
  y_ridge,
  alpha = 0
)
mejor_lambda_ridge <- cv_ridge$lambda.min
mejor_lambda_ridge
coeficientes_ridge <- coef(modelo_ridge, s = mejor_lambda_ridge)
coeficientes_ridge
predicciones_ridge <- predict(
  modelo_ridge,
  newx = x_ridge,
  s = mejor_lambda_ridge
)
mse_ridge <- mean((datos_precio$precio - predicciones_ridge)^2)
mse_ridge
# 12. Regresion con predictor no binario
# Se convierte condicion en factor

datos_factor <- datos_precio
datos_factor$condicion <- as.factor(datos_factor$condicion)

modelo_no_binario <- lm(
  precio ~ tcons + condicion + tterreno + numban + recamaras,
  data = datos_factor
)
summary(modelo_no_binario)
# 13. Regresion logistica binaria
# Se crea precio_alto a partir de la mediana del precio
datos_logistica <- datos_precio
mediana_precio <- median(datos_logistica$precio)
datos_logistica$precio_alto <- as.integer(
  datos_logistica$precio > mediana_precio
)
mediana_precio
table(datos_logistica$precio_alto)
modelo_logistico <- glm(
  precio_alto ~ recamaras + numban + tcons + tterreno + condicion,
  data = datos_logistica,
  family = binomial
)
summary(modelo_logistico)
Anova(modelo_logistico)
vif(modelo_logistico)
# 14. Regresion logistica multinomial
# Se crea categoria_precio: bajo, medio y alto
datos_multinom <- datos_precio
percentil_33 <- quantile(datos_multinom$precio, 0.33)
percentil_66 <- quantile(datos_multinom$precio, 0.66)
datos_multinom$categoria_precio <- cut(
  datos_multinom$precio,
  breaks = c(-Inf, percentil_33, percentil_66, Inf),
  labels = c("bajo", "medio", "alto"),
  right = FALSE
)
table(datos_multinom$categoria_precio)
modelo_multinom <- multinom(
  categoria_precio ~ recamaras + numban + tcons + tterreno + condicion,
  data = datos_multinom,
  trace = FALSE
)
summary(modelo_multinom)
coef(modelo_multinom)
nuevo_dato_multinom <- data.frame(
  recamaras = 3,
  numban = 2,
  tcons = 120,
  tterreno = 200,
  condicion = 3
)
predict(
  modelo_multinom,
  newdata = nuevo_dato_multinom,
  type = "probs"
)
# 15. K vecinos mas cercanos
# Clasificacion basica de precio en alto y bajo
datos_knn <- datos_precio
mediana_precio_knn <- median(datos_knn$precio)
datos_knn$categoria_precio <- ifelse(
  datos_knn$precio >= mediana_precio_knn,
  "alto",
  "bajo"
)
datos_knn$categoria_precio <- as.factor(datos_knn$categoria_precio)
datos_knn_selected <- datos_knn %>%
  select(
    recamaras,
    numban,
    tcons,
    tterreno,
    condicion,
    categoria_precio
  )
set.seed(42)
train_index <- sample(
  1:nrow(datos_knn_selected),
  0.75 * nrow(datos_knn_selected)
)
train_data <- datos_knn_selected[train_index, ]
test_data <- datos_knn_selected[-train_index, ]
train_x <- train_data %>% select(-categoria_precio)
test_x <- test_data %>% select(-categoria_precio)
train_x_scaled <- scale(train_x)
test_x_scaled <- scale(
  test_x,
  center = attr(train_x_scaled, "scaled:center"),
  scale = attr(train_x_scaled, "scaled:scale")
)
predicciones_knn <- knn(
  train = train_x_scaled,
  test = test_x_scaled,
  cl = train_data$categoria_precio,
  k = 3
)
head(predicciones_knn, 10)
# 16. Random Forest
# Prediccion de precio
datos_rf <- datos_precio
X_rf <- datos_rf[, !(colnames(datos_rf) %in% "precio")]
y_rf <- datos_rf$precio
set.seed(42)
train_indices_rf <- sample(
  1:nrow(datos_rf),
  0.8 * nrow(datos_rf)
)
X_train <- X_rf[train_indices_rf, ]
X_test <- X_rf[-train_indices_rf, ]
y_train <- y_rf[train_indices_rf]
y_test <- y_rf[-train_indices_rf]
modelo_rf <- randomForest(
  x = X_train,
  y = y_train,
  ntree = 100,
  importance = TRUE
)
modelo_rf
predicciones_rf <- predict(
  modelo_rf,
  newdata = X_test
)
rmse_rf <- sqrt(mean((y_test - predicciones_rf)^2))
mae_rf <- mean(abs(y_test - predicciones_rf))
r2_rf <- 1 - sum((y_test - predicciones_rf)^2) / sum((y_test - mean(y_test))^2)
rmse_rf
mae_rf
r2_rf
predicciones_rf_df <- data.frame(
  precio_real = y_test,
  precio_predicho = predicciones_rf
)
write.csv(
  predicciones_rf_df,
  "predicciones_random_forest.csv",
  row.names = FALSE
)
png("figura_2_importancia_variables_rf.png", width = 900, height = 650)
varImpPlot(modelo_rf, main = "Importancia de Variables")
dev.off()
# 17. Resumen final de resultados
resumen_resultados <- data.frame(
  Modelo = c(
    "Regresion lineal simple",
    "Lasso",
    "Ridge",
    "Random Forest"
  ),
  Metrica = c(
    "R-squared",
    "MSE",
    "MSE",
    "R-squared"
  ),
  Valor = c(
    summary(modelo_simple)$r.squared,
    as.numeric(mse_lasso),
    as.numeric(mse_ridge),
    as.numeric(r2_rf)
  )
)
resumen_resultados
write.csv(
  resumen_resultados,
  "resumen_resultados_practica8.csv",
  row.names = FALSE
)