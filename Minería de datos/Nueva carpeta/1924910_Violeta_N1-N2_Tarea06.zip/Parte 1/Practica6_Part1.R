# Practica 6 part1
library(readxl)
library(arules)
library(arulesViz)
library(RColorBrewer)

# Leer archivo AP.xlsx
df <- read_excel(file.choose(), sheet = 1, range = "A1:E51")

# Revisar datos
head(df)
summary(df)

# Renombrar columnas
names(df) <- c("HeartDisease", "BMI", "Smoking", "AlcoholDrinking", "Stroke")

# Corregir valores NA en AlcoholDrinking
df$AlcoholDrinking <- as.character(df$AlcoholDrinking)
df$AlcoholDrinking[is.na(df$AlcoholDrinking)] <- "No"
df$AlcoholDrinking[df$AlcoholDrinking == "NA"] <- "No"
df$AlcoholDrinking[df$AlcoholDrinking == ""] <- "No"

# Convertir BMI a numero
df$BMI <- as.numeric(df$BMI)

# Convertir BMI en categorias
df$BMI <- cut(
  df$BMI,
  breaks = c(-Inf, 18.5, 25, 30, Inf),
  labels = c("Bajo_peso", "Peso_normal", "Sobrepeso", "Obesidad"),
  right = FALSE
)

# Convertir todo a factor
df[] <- lapply(df, as.factor)

# Revisar datos ya preparados
head(df)
summary(df)

# Convertir a transacciones
trans <- as(df, "transactions")

# Revisar transacciones
summary(trans)
inspect(head(trans, 10))

# Grafica de frecuencia de items AP
itemFrequencyPlot(
  trans,
  topN = 20,
  main = "Relative Item Frequency Plot - AP",
  type = "relative",
  ylab = "Item Frequency Relative"
)

# Reglas AP con primer support y confidence
rules1 <- apriori(
  trans,
  parameter = list(supp = 0.01, conf = 0.1, minlen = 2)
)

summary(rules1)
inspect(head(sort(rules1, by = "lift"), 10))

# Guardar reglas AP 1 en CSV
rules_df1 <- as(sort(rules1, by = "lift"), "data.frame")
write.csv(rules_df1, file = "association_rules_AP_001_01.csv", row.names = FALSE)

# Reglas AP con segundo support y confidence
rules2 <- apriori(
  trans,
  parameter = list(supp = 0.05, conf = 0.3, minlen = 2)
)

summary(rules2)
inspect(head(sort(rules2, by = "lift"), 10))

# Guardar reglas AP 2 en CSV
rules_df2 <- as(sort(rules2, by = "lift"), "data.frame")
write.csv(rules_df2, file = "association_rules_AP_005_03.csv", row.names = FALSE)

# Reglas AP con tercer support y confidence
rules3 <- apriori(
  trans,
  parameter = list(supp = 0.1, conf = 0.5, minlen = 2)
)

summary(rules3)
inspect(head(sort(rules3, by = "lift"), 10))

# Guardar reglas AP 3 en CSV
rules_df3 <- as(sort(rules3, by = "lift"), "data.frame")
write.csv(rules_df3, file = "association_rules_AP_01_05.csv", row.names = FALSE)

# Reglas AP con cuarto support y confidence
rules4 <- apriori(
  trans,
  parameter = list(supp = 0.2, conf = 0.5, minlen = 2)
)

summary(rules4)
inspect(head(sort(rules4, by = "lift"), 10))

# Guardar reglas AP 4 en CSV
rules_df4 <- as(sort(rules4, by = "lift"), "data.frame")
write.csv(rules_df4, file = "association_rules_AP_02_05.csv", row.names = FALSE)

# Tabla resumen AP
resumen_AP <- data.frame(
  Dataset = c("AP", "AP", "AP", "AP"),
  Support = c(0.01, 0.05, 0.1, 0.2),
  Confidence = c(0.1, 0.3, 0.5, 0.5),
  Numero_Reglas = c(
    length(rules1),
    length(rules2),
    length(rules3),
    length(rules4)
  )
)

print(resumen_AP)
write.csv(resumen_AP, file = "resumen_resultados_AP.csv", row.names = FALSE)

# GROCERIES
data("Groceries")

# Revisar datos Groceries
summary(Groceries)

# Reglas Groceries con primer support y confidence
rules_groceries1 <- apriori(
  Groceries,
  parameter = list(supp = 0.01, conf = 0.1, minlen = 2)
)

summary(rules_groceries1)
inspect(head(sort(rules_groceries1, by = "lift"), 10))

# Guardar reglas Groceries 1 en CSV
rules_groceries_df1 <- as(sort(rules_groceries1, by = "lift"), "data.frame")
write.csv(rules_groceries_df1, file = "association_rules_Groceries_001_01.csv", row.names = FALSE)

# Reglas Groceries con segundo support y confidence
rules_groceries2 <- apriori(
  Groceries,
  parameter = list(supp = 0.005, conf = 0.3, minlen = 2)
)

summary(rules_groceries2)
inspect(head(sort(rules_groceries2, by = "lift"), 10))

# Guardar reglas Groceries 2 en CSV
rules_groceries_df2 <- as(sort(rules_groceries2, by = "lift"), "data.frame")
write.csv(rules_groceries_df2, file = "association_rules_Groceries_0005_03.csv", row.names = FALSE)

# Reglas Groceries con tercer support y confidence
rules_groceries3 <- apriori(
  Groceries,
  parameter = list(supp = 0.01, conf = 0.5, minlen = 2)
)

summary(rules_groceries3)
inspect(head(sort(rules_groceries3, by = "lift"), 10))

# Guardar reglas Groceries 3 en CSV
rules_groceries_df3 <- as(sort(rules_groceries3, by = "lift"), "data.frame")
write.csv(rules_groceries_df3, file = "association_rules_Groceries_001_05.csv", row.names = FALSE)

# Grafica de frecuencia de items Groceries
itemFrequencyPlot(
  Groceries,
  topN = 20,
  col = brewer.pal(8, "Pastel2"),
  main = "Relative Item Frequency Plot - Groceries",
  type = "relative",
  ylab = "Item Frequency Relative"
)

# Tabla resumen Groceries
resumen_Groceries <- data.frame(
  Dataset = c("Groceries", "Groceries", "Groceries"),
  Support = c(0.01, 0.005, 0.01),
  Confidence = c(0.1, 0.3, 0.5),
  Numero_Reglas = c(
    length(rules_groceries1),
    length(rules_groceries2),
    length(rules_groceries3)
  )
)

print(resumen_Groceries)
write.csv(resumen_Groceries, file = "resumen_resultados_Groceries.csv", row.names = FALSE)

# Resumen final
resumen_total <- rbind(resumen_AP, resumen_Groceries)

print(resumen_total)
write.csv(resumen_total, file = "resumen_total_practica6_parte1.csv", row.names = FALSE)