# PRACTICA 9 Matriz de confusion usando K-means clustering
library(dplyr)
# Seleccionar el archivo CSV
datos <- read.csv(file.choose())

# Revisar estructura del dataset
View(datos)
str(datos)
colnames(datos)

# Seleccion de variables numericas
datos_num <- datos %>%
  select(duration_ms, track_popularity, danceability, energy, key, loudness,
         speechiness, acousticness, instrumentalness, liveness, valence, tempo)

View(datos_num)
summary(datos_num)

# Escalamiento de datos
datos_scaled <- scale(datos_num)
View(datos_scaled)

# Clase real tomada del resultado de K-means
clase_real <- as.factor(datos$cluster_kmeans)

# Numero de grupos detectados
num_grupos <- length(unique(clase_real))
print(paste("Numero de grupos detectados:", num_grupos))

# Tupla original de K-means
print("Tupla original de K-means:")
print(table(clase_real))

# Funcion de clasificacion basada en vecinos cercanos
clasificar_knn_loo <- function(data_scaled, clases, k_vecinos = 3) {
  n <- nrow(data_scaled)
  predicciones <- character(n)
  for (i in 1:n) {
    # Calcular distancia euclidiana entre la instancia actual y las demas
    diferencias <- sweep(data_scaled, 2, data_scaled[i, ], "-")
    distancias <- sqrt(rowSums(diferencias^2))
    # Evitar que la instancia se compare consigo misma
    distancias[i] <- Inf
    # Obtener los k vecinos mas cercanos
    vecinos <- order(distancias)[1:k_vecinos]
    clases_vecinos <- clases[vecinos]
    # Votacion por mayoria
    conteo <- table(clases_vecinos)
    maximo <- max(conteo)
    candidatas <- names(conteo[conteo == maximo])
    # Si no hay empate, se asigna la clase mas frecuente
    if (length(candidatas) == 1) {
      predicciones[i] <- candidatas
    } else {
      # Si hay empate, se toma la clase del vecino mas cercano
      for (v in vecinos) {
        if (as.character(clases[v]) %in% candidatas) {
          predicciones[i] <- as.character(clases[v])
          break
        }
      }
    }
  }
  return(factor(predicciones, levels = levels(clases)))
}

# Aplicacion del clasificador
prediccion <- clasificar_knn_loo(datos_scaled, clase_real, k_vecinos = 3)

# Agregar la prediccion al dataset
datos$cluster_predicho <- prediccion
View(datos)

# Tupla del resultado predicho por el clasificador
print("Tupla del resultado predicho:")
print(table(prediccion))

# Matriz de confusion
matriz_confusion <- table(Real = clase_real, Predicho = prediccion)

print("Matriz de confusion:")
print(matriz_confusion)

print("Matriz de confusion con totales:")
print(addmargins(matriz_confusion))

# Calculo de metricas
# Accuracy global
accuracy <- sum(diag(matriz_confusion)) / sum(matriz_confusion)
print(paste("Accuracy global:", round(accuracy, 4)))

# Error global
error_global <- 1 - accuracy
print(paste("Error global:", round(error_global, 4)))

# Porcentaje por clase real
porcentaje_por_fila <- prop.table(matriz_confusion, margin = 1) * 100
print("Porcentaje por clase real:")
print(round(porcentaje_por_fila, 2))

# Precision por clase real
precision_por_clase <- diag(matriz_confusion) / rowSums(matriz_confusion)
print("Precision por clase real:")
print(round(precision_por_clase, 4))

# Instancias mal clasificadas
errores <- datos[clase_real != prediccion, 
                 c("artist_name", "track_name", "cluster_kmeans", "cluster_predicho")]
print("Instancias mal clasificadas:")
print(errores)

# Promedios por grupo para analizar causas de error
promedios_grupo <- datos %>%
  group_by(cluster_kmeans) %>%
  summarise(across(c(duration_ms, track_popularity, danceability, energy, key, loudness,
                     speechiness, acousticness, instrumentalness, liveness, valence, tempo),
                   mean, na.rm = TRUE))

print("Promedios por grupo:")
print(promedios_grupo, width = Inf)
# Guardar archivo final de la Practica 9

write.csv(datos, "spotify_latinos_practica9.csv", row.names = FALSE)